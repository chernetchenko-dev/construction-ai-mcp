using System;
using System.Collections.Generic;
using System.Linq;

namespace LoadCalcPlugin.Core
{
    // ────────────────────────────────────────────────────────────
    //  Перечисление категорий нагрузки (СП 256, раздел 7)
    // ────────────────────────────────────────────────────────────
    public enum LoadCategory
    {
        Lighting,       // Освещение      — §7.2.1, табл. 7.6
        Sockets,        // Розетки        — §7.2.4, табл. 7.7
        Power,          // Силовое обор.  — §7.2.6, табл. 7.8
        Lifts,          // Лифты          — §7.1.7, табл. 7.4
        Unknown         // Нераспознано
    }

    // ────────────────────────────────────────────────────────────
    //  Тип здания (влияет на Ксп освещения, табл. 7.6)
    // ────────────────────────────────────────────────────────────
    public enum BuildingType
    {
        Office,         // Организации управления, офисы
        Trade,          // Предприятия торговли
        Food,           // Общественное питание
        Hotel,          // Гостиницы
        School,         // Учебные заведения
        Culture,        // Клубы, Д/К
        Cinema,         // Кинотеатры
        ActHall,        // Актовые/конференц-залы (Ксп = 1.0)
        Other           // Прочие
    }

    // ────────────────────────────────────────────────────────────
    //  Одна строка расчёта (один тип нагрузки)
    // ────────────────────────────────────────────────────────────
    public class LoadLine
    {
        public string   Name        { get; set; }
        public LoadCategory Category { get; set; }
        public int      Count       { get; set; }
        public double   Pinstalled_kW { get; set; }   // Руст, кВт
        public double   Ksp         { get; set; }     // Коэффициент спроса
        public double   Pcalc_kW    { get; set; }     // Рр = Руст × Ксп, кВт
        public double   CosPhi      { get; set; }
        public double   TanPhi      => CosPhi > 0 ? Math.Sqrt(1 - CosPhi * CosPhi) / CosPhi : 0;
        public double   Qcalc_kVAR  => Pcalc_kW * TanPhi;
        public double   Scalc_kVA   => CosPhi > 0 ? Pcalc_kW / CosPhi : Pcalc_kW;

        // Источники (для отчёта): список элементов Revit
        public List<string> Sources { get; set; } = new List<string>();
    }

    // ────────────────────────────────────────────────────────────
    //  Итоговый результат ТРН
    // ────────────────────────────────────────────────────────────
    public class LoadCalcResult
    {
        public List<LoadLine> Lines     { get; set; } = new List<LoadLine>();
        public BuildingType   Building  { get; set; }
        public int            LiftCount { get; set; }
        public int            Floors    { get; set; }

        // Итоги до применения коэф. несовпадения
        public double TotalPinstalled => Lines.Sum(l => l.Pinstalled_kW);
        public double TotalPcalcRaw   => Lines.Sum(l => l.Pcalc_kW);
        public double TotalQcalcRaw   => Lines.Sum(l => l.Qcalc_kVAR);

        // Коэффициент несовпадения максимумов (табл. 7.11)
        public double Kcoincidence    { get; set; } = 1.0;

        // Итоговые расчётные значения на вводе
        public double TotalPcalc      => TotalPcalcRaw * Kcoincidence;
        public double TotalQcalc      => TotalQcalcRaw * Kcoincidence;
        public double TotalScalc
        {
            get
            {
                double p = TotalPcalc;
                double q = TotalQcalc;
                return Math.Sqrt(p * p + q * q);
            }
        }
        public double CosPhi_total
            => TotalScalc > 0 ? TotalPcalc / TotalScalc : 1.0;

        public string ProjectName { get; set; } = "";
        public string CalcEngineer { get; set; } = "";
        public DateTime CalcDate  { get; set; } = DateTime.Today;
    }

    // ────────────────────────────────────────────────────────────
    //  Основной калькулятор по СП 256
    // ────────────────────────────────────────────────────────────
    public static class LoadCalculator
    {
        // ─── Табл. 7.6 — Ксп рабочего освещения ────────────────
        // Ряды: (мощность кВт → Ксп) для типов зданий
        private static readonly double[] LightPowerSteps =
            { 5, 10, 15, 25, 50, 100, 200, 400, double.MaxValue };

        private static readonly Dictionary<BuildingType, double[]> LightKsp =
            new Dictionary<BuildingType, double[]>
        {
            { BuildingType.Hotel,   new[]{ 1.0, 0.80, 0.70, 0.60, 0.50, 0.40, 0.35, 0.30, 0.30 } },
            { BuildingType.Food,    new[]{ 1.0, 0.90, 0.85, 0.80, 0.75, 0.70, 0.65, 0.60, 0.50 } },
            { BuildingType.Trade,   new[]{ 1.0, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70, 0.65, 0.60 } },
            { BuildingType.Office,  new[]{ 1.0, 1.00, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70, 0.65 } },
            { BuildingType.School,  new[]{ 1.0, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70, 0.65, 0.60 } },
            { BuildingType.Culture, new[]{ 1.0, 0.90, 0.80, 0.75, 0.70, 0.65, 0.55, 0.55, 0.55 } },
            { BuildingType.Cinema,  new[]{ 1.0, 0.90, 0.80, 0.70, 0.65, 0.60, 0.50, 0.50, 0.50 } },
            { BuildingType.ActHall, new[]{ 1.0, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00 } },
            { BuildingType.Other,   new[]{ 1.0, 0.95, 0.90, 0.85, 0.80, 0.75, 0.70, 0.65, 0.60 } },
        };

        // ─── Табл. 7.7 — Ксп розеток (питающие сети/вводы) ─────
        // [0]=Office, [1]=Hotel/Food
        private static readonly double[] SocketKspFeeder  = { 0.20, 0.40 };
        private static readonly double[] SocketKspIntake  = { 0.10, 0.20 };

        // ─── Табл. 7.4 — Ксп лифтов ──────────────────────────
        //  (liftCount, floors≤12, floors>12)
        private static readonly (int MaxCount, double KspLow, double KspHigh)[] LiftKsp =
        {
            ( 3,  0.80, 0.90),
            ( 5,  0.70, 0.80),
            ( 6,  0.65, 0.75),
            (10,  0.50, 0.60),
            (20,  0.40, 0.50),
            (int.MaxValue, 0.35, 0.40),
        };

        // ─── cosφ по табл. 7.12 ──────────────────────────────
        public static readonly Dictionary<LoadCategory, double> DefaultCosPhi =
            new Dictionary<LoadCategory, double>
        {
            { LoadCategory.Lighting,  0.92  }, // люминесцентные/LED
            { LoadCategory.Sockets,   0.85  }, // смешанная нагрузка
            { LoadCategory.Power,     0.80  }, // сантех/вентил.
            { LoadCategory.Lifts,     0.65  }, // лифты
            { LoadCategory.Unknown,   0.90  },
        };

        // ─── Табл. 7.11 — Коэф. несовпадения максимумов ─────
        //  Значение для офисов при отношении осв./силовой 20–75%
        private static readonly Dictionary<BuildingType, double> KcoincidenceMap =
            new Dictionary<BuildingType, double>
        {
            { BuildingType.Office,  0.95 },
            { BuildingType.Trade,   0.90 },
            { BuildingType.Food,    0.90 },
            { BuildingType.Hotel,   0.90 },
            { BuildingType.School,  0.95 },
            { BuildingType.Culture, 0.90 },
            { BuildingType.Cinema,  0.90 },
            { BuildingType.ActHall, 1.00 },
            { BuildingType.Other,   0.95 },
        };

        // ════════════════════════════════════════════════════════
        //  Публичный API
        // ════════════════════════════════════════════════════════

        /// <summary>
        /// Получить Ксп освещения по табл. 7.6 с интерполяцией
        /// </summary>
        public static double GetLightingKsp(BuildingType bType, double pInstalled_kW)
        {
            if (!LightKsp.TryGetValue(bType, out var row))
                row = LightKsp[BuildingType.Other];

            for (int i = 0; i < LightPowerSteps.Length; i++)
                if (pInstalled_kW <= LightPowerSteps[i])
                {
                    if (i == 0) return row[0];
                    // Линейная интерполяция
                    double p0 = (i == 1) ? 0 : LightPowerSteps[i - 2];
                    double p1 = LightPowerSteps[i - 1];
                    double p2 = LightPowerSteps[i];
                    if (p2 - p1 < 1e-9) return row[i];
                    double t = (pInstalled_kW - p1) / (p2 - p1);
                    return row[i - 1] + t * (row[i] - row[i - 1]);
                }
            return row[row.Length - 1];
        }

        /// <summary>
        /// Получить Ксп розеток (питающая сеть/ввод)
        /// </summary>
        public static double GetSocketKsp(BuildingType bType, bool isIntake = true)
        {
            int idx = (bType == BuildingType.Hotel ||
                       bType == BuildingType.Food)  ? 1 : 0;
            return isIntake ? SocketKspIntake[idx] : SocketKspFeeder[idx];
        }

        /// <summary>
        /// Получить Ксп лифтов по табл. 7.4
        /// </summary>
        public static double GetLiftKsp(int count, int floors)
        {
            bool high = floors > 12;
            foreach (var row in LiftKsp)
                if (count <= row.MaxCount)
                    return high ? row.KspHigh : row.KspLow;
            return high ? 0.40 : 0.35;
        }

        /// <summary>
        /// Рассчитать всю ТРН для набора входных данных
        /// </summary>
        public static LoadCalcResult Calculate(
            double pLighting_kW,
            double pSockets_kW,
            double pPower_kW,
            double pLifts_kW,
            int    liftCount,
            int    floors,
            BuildingType bType,
            string projectName    = "",
            string calcEngineer   = "",
            List<string> lighSources  = null,
            List<string> sockSources  = null,
            List<string> powerSources = null,
            List<string> liftSources  = null)
        {
            var result = new LoadCalcResult
            {
                Building      = bType,
                LiftCount     = liftCount,
                Floors        = floors,
                ProjectName   = projectName,
                CalcEngineer  = calcEngineer,
                Kcoincidence  = KcoincidenceMap.TryGetValue(bType, out var kc) ? kc : 0.95,
            };

            // ── Освещение ──────────────────────────────────────
            if (pLighting_kW > 0)
            {
                double ksp = GetLightingKsp(bType, pLighting_kW);
                result.Lines.Add(new LoadLine
                {
                    Name         = "Освещение рабочее (табл. 7.6 СП 256)",
                    Category     = LoadCategory.Lighting,
                    Pinstalled_kW = pLighting_kW,
                    Ksp          = ksp,
                    Pcalc_kW     = pLighting_kW * ksp,
                    CosPhi       = DefaultCosPhi[LoadCategory.Lighting],
                    Sources      = lighSources ?? new List<string>(),
                });
            }

            // ── Розетки ────────────────────────────────────────
            if (pSockets_kW > 0)
            {
                double ksp = GetSocketKsp(bType, isIntake: true);
                result.Lines.Add(new LoadLine
                {
                    Name         = "Розетки (табл. 7.7 СП 256, ввод)",
                    Category     = LoadCategory.Sockets,
                    Pinstalled_kW = pSockets_kW,
                    Ksp          = ksp,
                    Pcalc_kW     = pSockets_kW * ksp,
                    CosPhi       = DefaultCosPhi[LoadCategory.Sockets],
                    Sources      = sockSources ?? new List<string>(),
                });
            }

            // ── Силовое (ОВиК, насосы, вентиляция) ────────────
            if (pPower_kW > 0)
            {
                const double ksp = 0.70; // §7.2.7 табл. 7.8, поз. 5 (сантех)
                result.Lines.Add(new LoadLine
                {
                    Name         = "Силовое оборудование (ОВиК, насосы, табл. 7.8 поз.5)",
                    Category     = LoadCategory.Power,
                    Pinstalled_kW = pPower_kW,
                    Ksp          = ksp,
                    Pcalc_kW     = pPower_kW * ksp,
                    CosPhi       = DefaultCosPhi[LoadCategory.Power],
                    Sources      = powerSources ?? new List<string>(),
                });
            }

            // ── Лифты ──────────────────────────────────────────
            if (pLifts_kW > 0 && liftCount > 0)
            {
                double ksp = GetLiftKsp(liftCount, floors);
                result.Lines.Add(new LoadLine
                {
                    Name         = $"Лифты ({liftCount} шт., {floors} эт., табл. 7.4 СП 256)",
                    Category     = LoadCategory.Lifts,
                    Count        = liftCount,
                    Pinstalled_kW = pLifts_kW,
                    Ksp          = ksp,
                    Pcalc_kW     = pLifts_kW * ksp,
                    CosPhi       = DefaultCosPhi[LoadCategory.Lifts],
                    Sources      = liftSources ?? new List<string>(),
                });
            }

            return result;
        }
    }
}
