using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.DB.Mechanical;

namespace LoadCalcPlugin.Core
{
    /// <summary>
    /// Агрегированные данные о нагрузке, считанные из модели Revit
    /// </summary>
    public class RevitLoadData
    {
        // Установленные мощности, Вт
        public double P_Lighting_W  { get; set; }
        public double P_Sockets_W   { get; set; }
        public double P_Power_W     { get; set; }
        public double P_Lifts_W     { get; set; }
        public int    LiftCount     { get; set; }

        // Элементы-источники (имя типа для отчёта)
        public List<string> LightingSources  { get; set; } = new List<string>();
        public List<string> SocketsSources   { get; set; } = new List<string>();
        public List<string> PowerSources     { get; set; } = new List<string>();
        public List<string> LiftSources      { get; set; } = new List<string>();

        // Нераспознанные (нет категории) — для диагностики
        public List<string> UnknownSources   { get; set; } = new List<string>();
        public double P_Unknown_W            { get; set; }
    }

    /// <summary>
    /// Правила сопоставления категории Revit → LoadCategory
    /// Задаются из настроек плагина и могут быть переопределены пользователем
    /// </summary>
    public class CategoryMapping
    {
        // Категории Revit → LoadCategory
        public Dictionary<BuiltInCategory, LoadCategory> BuiltInMap { get; set; }
            = new Dictionary<BuiltInCategory, LoadCategory>
            {
                { BuiltInCategory.OST_LightingFixtures,   LoadCategory.Lighting  },
                { BuiltInCategory.OST_ElectricalFixtures, LoadCategory.Sockets   },
                // Механическое оборудование — по умолчанию силовое
                { BuiltInCategory.OST_MechanicalEquipment, LoadCategory.Power    },
                // Электрооборудование — панели, трансформаторы → пропускаем
                // (лифты определяются по имени типа или параметру)
            };

        // Имя shared-параметра с явной категорией (приоритет выше чем BuiltInMap)
        // Значения: "Освещение", "Розетки", "Силовое", "Лифт", "Игнорировать"
        public string LoadCategoryParamName { get; set; } = "ЭОМ_КатегорияНагрузки";

        // Имя параметра с установленной мощностью (Вт)
        public string PowerParamName { get; set; } = "ADSK_Мощность";

        // Ключевые слова в имени семейства/типа для определения лифтов
        public string[] LiftKeywords { get; set; } = { "лифт", "lift", "elevator" };
    }

    /// <summary>
    /// Считывает нагрузки из Revit-модели, группирует по LoadCategory
    /// </summary>
    public static class RevitDataReader
    {
        private const double W_PER_KW = 1000.0;

        public static RevitLoadData ReadFromDocument(Document doc,
            CategoryMapping mapping)
        {
            var result = new RevitLoadData();

            // Категории, которые собираем
            var targetCats = new[]
            {
                BuiltInCategory.OST_LightingFixtures,
                BuiltInCategory.OST_ElectricalFixtures,
                BuiltInCategory.OST_MechanicalEquipment,
                BuiltInCategory.OST_ElectricalEquipment,
                BuiltInCategory.OST_GenericModel,
                BuiltInCategory.OST_SpecialityEquipment,
            };

            foreach (var bic in targetCats)
            {
                var collector = new FilteredElementCollector(doc)
                    .OfCategory(bic)
                    .WhereElementIsNotElementType()
                    .ToElements();

                foreach (var elem in collector)
                    ProcessElement(elem, bic, mapping, result);
            }

            return result;
        }

        // ────────────────────────────────────────────────────────
        private static void ProcessElement(Element elem,
            BuiltInCategory bic,
            CategoryMapping mapping,
            RevitLoadData result)
        {
            // 1) Получить установленную мощность (Вт)
            double powerW = GetPower_W(elem, mapping.PowerParamName);
            if (powerW <= 0) return;  // нет мощности — пропускаем

            // 2) Получить имя для отчёта
            string typeName = GetTypeName(elem);

            // 3) Определить категорию нагрузки
            LoadCategory cat = ResolveCategory(elem, bic, mapping);

            // 4) Добавить в соответствующую группу
            switch (cat)
            {
                case LoadCategory.Lighting:
                    result.P_Lighting_W += powerW;
                    result.LightingSources.Add($"{typeName} ({powerW:F0} Вт)");
                    break;

                case LoadCategory.Sockets:
                    result.P_Sockets_W += powerW;
                    result.SocketsSources.Add($"{typeName} ({powerW:F0} Вт)");
                    break;

                case LoadCategory.Power:
                    result.P_Power_W += powerW;
                    result.PowerSources.Add($"{typeName} ({powerW:F0} Вт)");
                    break;

                case LoadCategory.Lifts:
                    result.P_Lifts_W += powerW;
                    result.LiftCount++;
                    result.LiftSources.Add($"{typeName} ({powerW:F0} Вт)");
                    break;

                default:
                    result.P_Unknown_W += powerW;
                    result.UnknownSources.Add($"{typeName} ({powerW:F0} Вт) [категория не определена]");
                    break;
            }
        }

        // ────────────────────────────────────────────────────────
        private static LoadCategory ResolveCategory(Element elem,
            BuiltInCategory bic,
            CategoryMapping mapping)
        {
            // Приоритет 1: явный параметр на элементе
            var paramCat = elem.LookupParameter(mapping.LoadCategoryParamName);
            if (paramCat != null && paramCat.HasValue)
            {
                string val = paramCat.AsString()?.Trim().ToLowerInvariant() ?? "";
                if (val == "освещение" || val == "lighting")  return LoadCategory.Lighting;
                if (val == "розетки"  || val == "sockets")    return LoadCategory.Sockets;
                if (val == "силовое"  || val == "power")      return LoadCategory.Power;
                if (val == "лифт"     || val == "lift")       return LoadCategory.Lifts;
                if (val == "игнорировать" || val == "ignore") return LoadCategory.Unknown;
            }

            // Приоритет 2: ключевые слова лифта в имени типа
            string typeName = GetTypeName(elem).ToLowerInvariant();
            foreach (var kw in mapping.LiftKeywords)
                if (typeName.Contains(kw.ToLowerInvariant()))
                    return LoadCategory.Lifts;

            // Приоритет 3: карта по BuiltInCategory
            if (mapping.BuiltInMap.TryGetValue(bic, out var mapped))
                return mapped;

            return LoadCategory.Unknown;
        }

        // ────────────────────────────────────────────────────────
        private static double GetPower_W(Element elem, string paramName)
        {
            // Сначала пробуем ADSK_Мощность (shared, единицы — Вт)
            var p = elem.LookupParameter(paramName);
            if (p != null && p.HasValue)
            {
                // ADSK_Мощность хранится в Вт (тип Number, не Length)
                // В Revit API числовые параметры без размерности — просто double
                return Math.Abs(p.AsDouble());
            }

            // Запасной вариант: встроенный параметр ApparentLoad (ВА → Вт при cosφ≈1)
            var builtIn = elem.get_Parameter(BuiltInParameter.RBS_ELEC_APPARENT_LOAD);
            if (builtIn != null && builtIn.HasValue)
            {
                // Единица Revit — VA; переводим: VA≈W при cosφ=1 (пессимистично)
                double va = builtIn.AsDouble();
                // В Revit 2024 единицы нагрузки — VA (не футо-фунты)
                return Math.Abs(va);
            }

            return 0;
        }

        // ────────────────────────────────────────────────────────
        private static string GetTypeName(Element elem)
        {
            try
            {
                var typeId  = elem.GetTypeId();
                var famType = elem.Document.GetElement(typeId);
                if (famType != null) return famType.Name;
            }
            catch { }
            return elem.Name ?? "Неизвестно";
        }
    }
}
