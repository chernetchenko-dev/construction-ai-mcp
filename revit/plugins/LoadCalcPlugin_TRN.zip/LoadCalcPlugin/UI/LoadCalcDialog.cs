using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using LoadCalcPlugin.Core;

namespace LoadCalcPlugin.UI
{
    /// <summary>
    /// Диалог настройки ТРН перед выгрузкой в Excel
    /// Code-only WPF (без XAML), совместимо с Revit addin
    /// </summary>
    public class LoadCalcDialog : Window
    {
        // ── Входные данные (из модели) ─────────────────────────
        private readonly RevitLoadData _revitData;

        // ── Результат ─────────────────────────────────────────
        public LoadCalcSettings ResultSettings { get; private set; }
        public bool Confirmed { get; private set; }

        // ── Контролы ──────────────────────────────────────────
        private ComboBox  _cmbBuilding;
        private TextBox   _txtFloors;
        private TextBox   _txtProjectName;
        private TextBox   _txtEngineer;
        private TextBox   _txtOutputPath;

        // Мощности (авто из Revit, но редактируемые)
        private TextBox   _txtPLight;
        private TextBox   _txtPSockets;
        private TextBox   _txtPPower;
        private TextBox   _txtPLifts;
        private TextBox   _txtLiftCount;

        // Коэф. несовпадения (авто/ручной)
        private CheckBox  _chkAutoKc;
        private TextBox   _txtKc;

        // cosφ (редактируемые)
        private TextBox   _txtCosPhi_L;
        private TextBox   _txtCosPhi_S;
        private TextBox   _txtCosPhi_P;
        private TextBox   _txtCosPhi_Lift;

        // ── Строки предпросмотра Ксп ──────────────────────────
        private TextBlock _lblKspLight;
        private TextBlock _lblKspSock;
        private TextBlock _lblKspPower;
        private TextBlock _lblKspLift;

        public LoadCalcDialog(RevitLoadData revitData, string defaultProjectName = "")
        {
            _revitData = revitData;
            Title      = "ТРН — Таблица расчётных нагрузок (СП 256.1325800.2016)";
            Width      = 620;
            Height     = 700;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;

            Content = BuildLayout(defaultProjectName);
            PopulateFromRevitData();
        }

        // ════════════════════════════════════════════════════════
        //  Построение интерфейса
        // ════════════════════════════════════════════════════════
        private UIElement BuildLayout(string defaultProject)
        {
            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            var root   = new StackPanel { Margin = new Thickness(12) };
            scroll.Content = root;

            // ─── Проект ─────────────────────────────────────
            root.Children.Add(MakeHeader("Проект"));
            root.Children.Add(MakeRow("Наименование проекта:", out _txtProjectName, defaultProject));
            root.Children.Add(MakeRow("Инженер-разработчик:",  out _txtEngineer, ""));

            // ─── Параметры здания ───────────────────────────
            root.Children.Add(MakeHeader("Здание"));

            var rowBld = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            rowBld.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(200) });
            rowBld.ColumnDefinitions.Add(new ColumnDefinition());
            rowBld.Children.Add(new TextBlock { Text = "Тип здания:", VerticalAlignment = VerticalAlignment.Center });
            _cmbBuilding = new ComboBox { Margin = new Thickness(4, 0, 0, 0) };
            foreach (var bt in (BuildingType[])Enum.GetValues(typeof(BuildingType)))
                _cmbBuilding.Items.Add(new ComboBoxItem { Content = BuildingTypeLabel(bt), Tag = bt });
            _cmbBuilding.SelectedIndex = 0;
            _cmbBuilding.SelectionChanged += (s, e) => RefreshKsp();
            Grid.SetColumn(_cmbBuilding, 1);
            rowBld.Children.Add(_cmbBuilding);
            root.Children.Add(rowBld);

            root.Children.Add(MakeRow("Этажность здания:", out _txtFloors, "9"));
            _txtFloors.TextChanged += (s, e) => RefreshKsp();

            // ─── Нагрузки из Revit ──────────────────────────
            root.Children.Add(MakeHeader("Установленные мощности (из модели, кВт)"));

            root.Children.Add(MakeLoadRow("Освещение:",
                out _txtPLight, out _lblKspLight, "Ксп: —"));
            root.Children.Add(MakeLoadRow("Розетки:",
                out _txtPSockets, out _lblKspSock, "Ксп: —"));
            root.Children.Add(MakeLoadRow("Силовое оборудование:",
                out _txtPPower, out _lblKspPower, "Ксп: —"));
            root.Children.Add(MakeLoadRow("Лифты (суммарно):",
                out _txtPLifts, out _lblKspLift, "Ксп: —"));
            root.Children.Add(MakeRow("Количество лифтов, шт:", out _txtLiftCount, "0"));
            _txtLiftCount.TextChanged += (s, e) => RefreshKsp();

            // ─── cosφ ────────────────────────────────────────
            root.Children.Add(MakeHeader("Коэффициенты мощности cosφ (табл. 7.12)"));
            root.Children.Add(MakeRow("Освещение:",       out _txtCosPhi_L,    "0.92"));
            root.Children.Add(MakeRow("Розетки:",          out _txtCosPhi_S,    "0.85"));
            root.Children.Add(MakeRow("Силовое:",          out _txtCosPhi_P,    "0.80"));
            root.Children.Add(MakeRow("Лифты:",            out _txtCosPhi_Lift, "0.65"));

            // ─── Коэф. несовпадения ──────────────────────────
            root.Children.Add(MakeHeader("Коэффициент несовпадения максимумов К (табл. 7.11)"));
            _chkAutoKc = new CheckBox
            {
                Content = "Определять автоматически по типу здания",
                IsChecked = true, Margin = new Thickness(0, 2, 0, 2)
            };
            _chkAutoKc.Checked   += (s, e) => { _txtKc.IsEnabled = false; RefreshKsp(); };
            _chkAutoKc.Unchecked += (s, e) => _txtKc.IsEnabled = true;
            root.Children.Add(_chkAutoKc);
            root.Children.Add(MakeRow("К (ручной ввод):", out _txtKc, "0.95"));
            _txtKc.IsEnabled = false;

            // ─── Путь файла ──────────────────────────────────
            root.Children.Add(MakeHeader("Файл Excel"));
            var pathRow = new StackPanel { Orientation = Orientation.Horizontal,
                                           Margin = new Thickness(0, 2, 0, 4) };
            _txtOutputPath = new TextBox { Width = 380, Margin = new Thickness(0, 0, 4, 0),
                                           Text = GetDefaultExcelPath() };
            var btnBrowse  = new Button { Content = "…", Width = 30 };
            btnBrowse.Click += BrowseExcelPath;
            pathRow.Children.Add(new TextBlock { Text = "Сохранить в:",
                Width = 120, VerticalAlignment = VerticalAlignment.Center });
            pathRow.Children.Add(_txtOutputPath);
            pathRow.Children.Add(btnBrowse);
            root.Children.Add(pathRow);

            // ─── Кнопки ──────────────────────────────────────
            var btnRow = new StackPanel { Orientation = Orientation.Horizontal,
                                          HorizontalAlignment = HorizontalAlignment.Right,
                                          Margin = new Thickness(0, 8, 0, 0) };
            var btnOk  = new Button { Content = "Рассчитать и сохранить",
                                       Width = 180, Height = 28, Margin = new Thickness(0, 0, 8, 0),
                                       IsDefault = true };
            var btnCancel = new Button { Content = "Отмена", Width = 80, Height = 28,
                                          IsCancel = true };
            btnOk.Click     += BtnOk_Click;
            btnCancel.Click += (s, e) => Close();
            btnRow.Children.Add(btnOk);
            btnRow.Children.Add(btnCancel);
            root.Children.Add(btnRow);

            return scroll;
        }

        // ════════════════════════════════════════════════════════
        //  Заполнение из данных Revit
        // ════════════════════════════════════════════════════════
        private void PopulateFromRevitData()
        {
            _txtPLight.Text    = (_revitData.P_Lighting_W / 1000.0).ToString("F2");
            _txtPSockets.Text  = (_revitData.P_Sockets_W  / 1000.0).ToString("F2");
            _txtPPower.Text    = (_revitData.P_Power_W    / 1000.0).ToString("F2");
            _txtPLifts.Text    = (_revitData.P_Lifts_W    / 1000.0).ToString("F2");
            _txtLiftCount.Text = _revitData.LiftCount.ToString();
            RefreshKsp();
        }

        // ════════════════════════════════════════════════════════
        //  Обновление предпросмотра Ксп
        // ════════════════════════════════════════════════════════
        private void RefreshKsp()
        {
            var bType  = GetSelectedBuildingType();
            int floors = TryParseInt(_txtFloors?.Text, 9);
            int liftN  = TryParseInt(_txtLiftCount?.Text, 0);
            double pL  = TryParseDouble(_txtPLight?.Text, 0);
            double pS  = TryParseDouble(_txtPSockets?.Text, 0);

            if (_lblKspLight  != null)
                _lblKspLight.Text  = $"Ксп = {LoadCalculator.GetLightingKsp(bType, pL):F2}";
            if (_lblKspSock   != null)
                _lblKspSock.Text   = $"Ксп = {LoadCalculator.GetSocketKsp(bType, true):F2}";
            if (_lblKspPower  != null)
                _lblKspPower.Text  = "Ксп = 0.70";
            if (_lblKspLift   != null)
                _lblKspLift.Text   = liftN > 0
                    ? $"Ксп = {LoadCalculator.GetLiftKsp(liftN, floors):F2}"
                    : "Ксп = —";

            // Авто Кс несовпадения
            if (_chkAutoKc != null && _chkAutoKc.IsChecked == true && _txtKc != null)
            {
                // Определяем примерное соотношение осв./силовая
                // и берём из словаря (упрощённо)
                double kc = GetAutoKcoincidence(bType);
                _txtKc.Text = kc.ToString("F2");
            }
        }

        private double GetAutoKcoincidence(BuildingType bType)
        {
            var map = new Dictionary<BuildingType, double>
            {
                { BuildingType.Office,  0.95 }, { BuildingType.Trade,  0.90 },
                { BuildingType.Food,    0.90 }, { BuildingType.Hotel,  0.90 },
                { BuildingType.School,  0.95 }, { BuildingType.Culture, 0.90},
                { BuildingType.Cinema,  0.90 }, { BuildingType.ActHall, 1.00},
                { BuildingType.Other,   0.95 },
            };
            return map.TryGetValue(bType, out var v) ? v : 0.95;
        }

        // ════════════════════════════════════════════════════════
        //  Кнопка OK — сборка настроек
        // ════════════════════════════════════════════════════════
        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ResultSettings = new LoadCalcSettings
                {
                    BuildingType  = GetSelectedBuildingType(),
                    Floors        = TryParseInt(_txtFloors.Text, 9),
                    ProjectName   = _txtProjectName.Text.Trim(),
                    Engineer      = _txtEngineer.Text.Trim(),
                    OutputPath    = _txtOutputPath.Text.Trim(),

                    P_Lighting_kW = TryParseDouble(_txtPLight.Text, 0),
                    P_Sockets_kW  = TryParseDouble(_txtPSockets.Text, 0),
                    P_Power_kW    = TryParseDouble(_txtPPower.Text, 0),
                    P_Lifts_kW    = TryParseDouble(_txtPLifts.Text, 0),
                    LiftCount     = TryParseInt(_txtLiftCount.Text, 0),

                    CosPhi_Lighting = TryParseDouble(_txtCosPhi_L.Text, 0.92),
                    CosPhi_Sockets  = TryParseDouble(_txtCosPhi_S.Text, 0.85),
                    CosPhi_Power    = TryParseDouble(_txtCosPhi_P.Text, 0.80),
                    CosPhi_Lifts    = TryParseDouble(_txtCosPhi_Lift.Text, 0.65),

                    Kcoincidence  = TryParseDouble(_txtKc.Text, 0.95),

                    // Источники из Revit (для листа детализации)
                    RevitData     = _revitData,
                };

                Confirmed = true;
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка ввода данных:\n" + ex.Message, "ТРН",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // ════════════════════════════════════════════════════════
        //  Вспомогательные методы UI
        // ════════════════════════════════════════════════════════
        private UIElement MakeHeader(string text)
        {
            return new TextBlock
            {
                Text       = text,
                FontWeight = FontWeights.Bold,
                Margin     = new Thickness(0, 10, 0, 2),
                FontSize   = 12,
            };
        }

        private UIElement MakeRow(string label, out TextBox tb, string defaultVal)
        {
            var row = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(200) });
            row.ColumnDefinitions.Add(new ColumnDefinition());
            row.Children.Add(new TextBlock
            {
                Text = label, VerticalAlignment = VerticalAlignment.Center
            });
            tb = new TextBox { Text = defaultVal, Margin = new Thickness(4, 0, 0, 0) };
            Grid.SetColumn(tb, 1);
            row.Children.Add(tb);
            return row;
        }

        private UIElement MakeLoadRow(string label, out TextBox tbPower,
            out TextBlock tbKsp, string kspDefault)
        {
            var row = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(200) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(100) });
            row.ColumnDefinitions.Add(new ColumnDefinition());
            row.Children.Add(new TextBlock
            {
                Text = label, VerticalAlignment = VerticalAlignment.Center
            });
            tbPower = new TextBox { Text = "0.00", Margin = new Thickness(4, 0, 4, 0) };
            tbPower.TextChanged += (s, e) => RefreshKsp();
            Grid.SetColumn(tbPower, 1);
            row.Children.Add(tbPower);
            tbKsp = new TextBlock
            {
                Text = kspDefault, VerticalAlignment = VerticalAlignment.Center,
                Foreground = System.Windows.Media.Brushes.DarkBlue
            };
            Grid.SetColumn(tbKsp, 2);
            row.Children.Add(tbKsp);
            return row;
        }

        private void BrowseExcelPath(object sender, RoutedEventArgs e)
        {
            // Microsoft.Win32 не требует ссылок на WinForms
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title      = "Сохранить ТРН",
                Filter     = "Excel файл (*.xlsx)|*.xlsx",
                FileName   = "ТРН_" + DateTime.Today.ToString("yyyyMMdd"),
                DefaultExt = ".xlsx",
            };
            if (dlg.ShowDialog() == true)
                _txtOutputPath.Text = dlg.FileName;
        }

        private BuildingType GetSelectedBuildingType()
        {
            if (_cmbBuilding?.SelectedItem is ComboBoxItem item && item.Tag is BuildingType bt)
                return bt;
            return BuildingType.Office;
        }

        private static string BuildingTypeLabel(BuildingType bt) => bt switch
        {
            BuildingType.Office  => "Офисы / организации управления",
            BuildingType.Trade   => "Предприятия торговли",
            BuildingType.Food    => "Предприятия общественного питания",
            BuildingType.Hotel   => "Гостиницы",
            BuildingType.School  => "Учебные заведения",
            BuildingType.Culture => "Клубы / дома культуры",
            BuildingType.Cinema  => "Кинотеатры",
            BuildingType.ActHall => "Актовые / конференц-залы",
            _                    => "Прочие здания"
        };

        private static string GetDefaultExcelPath()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            return System.IO.Path.Combine(desktop,
                $"ТРН_{DateTime.Today:yyyyMMdd}.xlsx");
        }

        private static double TryParseDouble(string s, double def)
        {
            if (double.TryParse(s?.Replace(',', '.'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out double v))
                return v;
            return def;
        }

        private static int TryParseInt(string s, int def)
        {
            return int.TryParse(s, out int v) ? v : def;
        }
    }

    // ════════════════════════════════════════════════════════════
    //  DTO — настройки для расчёта
    // ════════════════════════════════════════════════════════════
    public class LoadCalcSettings
    {
        public BuildingType BuildingType   { get; set; }
        public int          Floors         { get; set; }
        public string       ProjectName    { get; set; }
        public string       Engineer       { get; set; }
        public string       OutputPath     { get; set; }

        public double P_Lighting_kW        { get; set; }
        public double P_Sockets_kW         { get; set; }
        public double P_Power_kW           { get; set; }
        public double P_Lifts_kW           { get; set; }
        public int    LiftCount            { get; set; }

        public double CosPhi_Lighting      { get; set; } = 0.92;
        public double CosPhi_Sockets       { get; set; } = 0.85;
        public double CosPhi_Power         { get; set; } = 0.80;
        public double CosPhi_Lifts         { get; set; } = 0.65;

        public double Kcoincidence         { get; set; } = 0.95;

        public RevitLoadData RevitData     { get; set; }
    }
}
