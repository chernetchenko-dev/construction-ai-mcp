// ════════════════════════════════════════════════════════════
//  CmdLoadCalc.cs — Команда Revit «Таблица расчётных нагрузок»
// ════════════════════════════════════════════════════════════
using System;
using System.Collections.Generic;
using System.IO;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using LoadCalcPlugin.Core;
using LoadCalcPlugin.Excel;
using LoadCalcPlugin.UI;

namespace LoadCalcPlugin.Commands
{
    /// <summary>
    /// Команда: читает нагрузки из Revit → показывает диалог → сохраняет ТРН в Excel
    /// </summary>
    [Transaction(TransactionMode.ReadOnly)]
    [Regeneration(RegenerationOption.Manual)]
    public class CmdLoadCalc : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData,
            ref string message, ElementSet elements)
        {
            var uiDoc = commandData.Application.ActiveUIDocument;
            var doc   = uiDoc?.Document;
            if (doc == null)
            {
                TaskDialog.Show("ТРН", "Нет открытого документа Revit.");
                return Result.Failed;
            }

            try
            {
                // ── 1. Считать данные из модели ───────────────
                var mapping  = new CategoryMapping();  // настройки по умолчанию
                var revitData = RevitDataReader.ReadFromDocument(doc, mapping);

                // ── 2. Показать диалог настройки ──────────────
                string projName = doc.ProjectInformation?.Name ?? "";
                var dialog = new LoadCalcDialog(revitData, projName);
                dialog.ShowDialog();

                if (!dialog.Confirmed)
                    return Result.Cancelled;

                var settings = dialog.ResultSettings;

                // ── 3. Запустить расчёт ───────────────────────
                var calc = LoadCalculator.Calculate(
                    pLighting_kW  : settings.P_Lighting_kW,
                    pSockets_kW   : settings.P_Sockets_kW,
                    pPower_kW     : settings.P_Power_kW,
                    pLifts_kW     : settings.P_Lifts_kW,
                    liftCount     : settings.LiftCount,
                    floors        : settings.Floors,
                    bType         : settings.BuildingType,
                    projectName   : settings.ProjectName,
                    calcEngineer  : settings.Engineer,
                    lighSources   : revitData.LightingSources,
                    sockSources   : revitData.SocketsSources,
                    powerSources  : revitData.PowerSources,
                    liftSources   : revitData.LiftSources);

                // Перекрыть cosφ из диалога
                OverrideCosPhiFromSettings(calc, settings);

                // Перекрыть Кс из диалога
                calc.Kcoincidence = settings.Kcoincidence;

                // ── 4. Сохранить Excel ────────────────────────
                string outPath = settings.OutputPath;
                if (string.IsNullOrWhiteSpace(outPath))
                    outPath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                        $"ТРН_{DateTime.Today:yyyyMMdd}.xlsx");

                ExcelExporter.Export(calc, settings, outPath);

                // ── 5. Сообщение об успехе ────────────────────
                string summary = BuildSummary(calc, outPath, revitData);
                var td = new TaskDialog("ТРН — Расчёт завершён") { MainContent = summary };
                td.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "Открыть файл Excel");
                td.AddCommandLink(TaskDialogCommandLinkId.CommandLink2, "Закрыть");
                var tdResult = td.Show();
                if (tdResult == TaskDialogResult.CommandLink1)
                {
                    try { System.Diagnostics.Process.Start(outPath); }
                    catch { /* Excel может быть не установлен */ }
                }

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = $"Ошибка ТРН:\n{ex.Message}\n\n{ex.StackTrace}";
                TaskDialog.Show("ТРН — Ошибка", message);
                return Result.Failed;
            }
        }

        // ────────────────────────────────────────────────────────
        private static void OverrideCosPhiFromSettings(LoadCalcResult calc,
            LoadCalcSettings s)
        {
            foreach (var line in calc.Lines)
            {
                switch (line.Category)
                {
                    case LoadCategory.Lighting: line.CosPhi = s.CosPhi_Lighting; break;
                    case LoadCategory.Sockets:  line.CosPhi = s.CosPhi_Sockets;  break;
                    case LoadCategory.Power:    line.CosPhi = s.CosPhi_Power;    break;
                    case LoadCategory.Lifts:    line.CosPhi = s.CosPhi_Lifts;    break;
                }
            }
        }

        private static string BuildSummary(LoadCalcResult calc,
            string outPath, RevitLoadData data)
        {
            return $"Расчёт выполнен по СП 256.1325800.2016\n\n" +
                   $"Руст суммарная:   {calc.TotalPinstalled:F1} кВт\n" +
                   $"Рр на вводе:       {calc.TotalPcalc:F1} кВт\n" +
                   $"Qр на вводе:       {calc.TotalQcalc:F1} квар\n" +
                   $"Sр на вводе:       {calc.TotalScalc:F1} кВА\n" +
                   $"cosφ ср.:          {calc.CosPhi_total:F2}\n\n" +
                   $"Нераспознанных:    {data.P_Unknown_W / 1000.0:F1} кВт\n\n" +
                   $"Файл сохранён:\n{outPath}";
        }
    }
}


// ════════════════════════════════════════════════════════════
//  App.cs — IExternalApplication, регистрация ribbon-кнопки
// ════════════════════════════════════════════════════════════
namespace LoadCalcPlugin
{
    using Autodesk.Revit.UI;
    using System.Reflection;

    public class App : IExternalApplication
    {
        public Result OnStartup(UIControlledApplication app)
        {
            try
            {
                string tabName = "ЭОМ";
                try { app.CreateRibbonTab(tabName); } catch { }

                var panel = app.CreateRibbonPanel(tabName, "Расчёт нагрузок");

                string dll = Assembly.GetExecutingAssembly().Location;

                var btnData = new PushButtonData(
                    "CmdLoadCalc",
                    "ТРН\nНагрузки",
                    dll,
                    "LoadCalcPlugin.Commands.CmdLoadCalc")
                {
                    ToolTip     = "Таблица расчётных нагрузок по СП 256.1325800.2016\n" +
                                  "Читает ADSK_Мощность из модели, рассчитывает Рр,\n" +
                                  "Qр, cosφ и сохраняет Excel.",
                    LongDescription =
                        "Алгоритм:\n" +
                        "1. Сбор семейств (OST_Lighting, OST_Electrical, OST_Mechanical)\n" +
                        "2. Чтение ADSK_Мощность (Вт)\n" +
                        "3. Категоризация: освещение / розетки / силовое / лифты\n" +
                        "4. Ксп по СП 256 (табл. 7.4, 7.6, 7.7, 7.8)\n" +
                        "5. Коэффициент несовпадения К (табл. 7.11)\n" +
                        "6. Формирование Excel ТРН (3 листа)",
                };

                // Иконка — встроенный PNG 32×32 (добавить в Resources)
                try
                {
                    string iconPath = System.IO.Path.Combine(
                        System.IO.Path.GetDirectoryName(dll) ?? "",
                        "Resources", "trn_icon.png");
                    if (System.IO.File.Exists(iconPath))
                    {
                        var img = new System.Windows.Media.Imaging.BitmapImage(
                            new System.Uri(iconPath));
                        btnData.LargeImage = img;
                    }
                }
                catch { /* иконка необязательна */ }

                panel.AddItem(btnData);
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("ТРН — Ошибка загрузки", ex.Message);
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication app) => Result.Succeeded;
    }
}
