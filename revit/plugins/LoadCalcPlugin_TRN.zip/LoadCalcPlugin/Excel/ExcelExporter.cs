using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ClosedXML.Excel;
using LoadCalcPlugin.Core;
using LoadCalcPlugin.UI;

namespace LoadCalcPlugin.Excel
{
    /// <summary>
    /// Генерирует файл Excel ТРН по результатам расчёта.
    /// Зависимость: ClosedXML (NuGet: ClosedXML 0.102.x, net48-совместима)
    /// </summary>
    public static class ExcelExporter
    {
        // ── Цвета ─────────────────────────────────────────────
        private static readonly XLColor ClrHeader    = XLColor.FromHtml("#1F4E79");
        private static readonly XLColor ClrSubHeader = XLColor.FromHtml("#2E75B6");
        private static readonly XLColor ClrRowOdd    = XLColor.FromHtml("#DDEEFF");
        private static readonly XLColor ClrRowEven   = XLColor.White;
        private static readonly XLColor ClrTotal     = XLColor.FromHtml("#FFF2CC");
        private static readonly XLColor ClrResult    = XLColor.FromHtml("#E2EFDA");
        private static readonly XLColor ClrUnknown   = XLColor.FromHtml("#FCE4D6");

        // ════════════════════════════════════════════════════════
        //  Главный метод экспорта
        // ════════════════════════════════════════════════════════
        public static void Export(LoadCalcResult calc, LoadCalcSettings settings,
            string outputPath)
        {
            using var wb = new XLWorkbook();

            // Лист 1: Сводная ТРН
            BuildSummarySheet(wb, calc, settings);

            // Лист 2: Детализация (источники из Revit)
            if (settings.RevitData != null)
                BuildDetailSheet(wb, settings.RevitData, settings);

            // Лист 3: Справочные Ксп
            BuildRefSheet(wb, calc);

            wb.SaveAs(outputPath);
        }

        // ════════════════════════════════════════════════════════
        //  Лист 1 — Сводная ТРН
        // ════════════════════════════════════════════════════════
        private static void BuildSummarySheet(IXLWorkbook wb,
            LoadCalcResult calc, LoadCalcSettings settings)
        {
            var ws = wb.Worksheets.Add("ТРН");
            ws.PageSetup.PaperSize  = XLPaperSize.A4Paper;
            ws.PageSetup.Orientation = XLPageOrientation.Landscape;

            int row = 1;

            // ── Заголовок ─────────────────────────────────────
            ws.Cell(row, 1).Value = "ТАБЛИЦА РАСЧЁТНЫХ НАГРУЗОК";
            SetMerge(ws, row, 1, row, 10,
                bold: true, fontSize: 14, hAlign: XLAlignmentHorizontalValues.Center,
                bgColor: ClrHeader, fgColor: XLColor.White);
            row++;

            ws.Cell(row, 1).Value = $"по СП 256.1325800.2016 «Электроустановки жилых и общественных зданий»";
            SetMerge(ws, row, 1, row, 10,
                bold: false, fontSize: 10, hAlign: XLAlignmentHorizontalValues.Center,
                bgColor: ClrHeader, fgColor: XLColor.FromHtml("#BDD7EE"));
            row++;

            // ── Реквизиты ─────────────────────────────────────
            row++;
            WriteInfoRow(ws, row++, "Наименование объекта:", settings.ProjectName);
            WriteInfoRow(ws, row++, "Тип здания:",           BuildingTypeText(calc.Building));
            WriteInfoRow(ws, row++, "Инженер-расчётчик:",    settings.Engineer);
            WriteInfoRow(ws, row++, "Дата расчёта:",         calc.CalcDate.ToString("dd.MM.yyyy"));
            WriteInfoRow(ws, row++, "Этажность:",            $"{calc.Floors} эт.");
            row++;

            // ── Заголовок таблицы ─────────────────────────────
            string[] hdr1 = {
                "№", "Наименование потребителя", "Норматив",
                "Руст\nкВт", "Ксп", "Рр\nкВт",
                "cosφ", "tgφ", "Qр\nквар", "Sр\nкВА"
            };
            int[] widths = { 4, 42, 28, 10, 8, 10, 8, 8, 10, 10 };
            for (int c = 0; c < hdr1.Length; c++)
            {
                var cell = ws.Cell(row, c + 1);
                cell.Value = hdr1[c];
                cell.Style.Font.Bold = true;
                cell.Style.Font.FontColor = XLColor.White;
                cell.Style.Fill.BackgroundColor = ClrSubHeader;
                cell.Style.Alignment.WrapText = true;
                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                cell.Style.Alignment.Vertical   = XLAlignmentVerticalValues.Center;
                cell.Style.Border.OutsideBorder  = XLBorderStyleValues.Thin;
                ws.Column(c + 1).Width = widths[c];
            }
            ws.Row(row).Height = 32;
            row++;
            int dataStartRow = row;

            // ── Строки нагрузок ──────────────────────────────
            int lineNum = 1;
            foreach (var line in calc.Lines)
            {
                bool odd = (lineNum % 2 == 1);
                var bg   = odd ? ClrRowOdd : ClrRowEven;
                var r    = row;

                ws.Cell(r, 1).Value  = lineNum;
                ws.Cell(r, 2).Value  = line.Name;
                ws.Cell(r, 3).Value  = LineNormRef(line.Category);
                ws.Cell(r, 4).Value  = Math.Round(line.Pinstalled_kW, 2);
                ws.Cell(r, 5).Value  = Math.Round(line.Ksp, 2);
                ws.Cell(r, 6).Value  = Math.Round(line.Pcalc_kW, 2);
                ws.Cell(r, 7).Value  = Math.Round(line.CosPhi, 2);
                ws.Cell(r, 8).Value  = Math.Round(line.TanPhi, 2);
                ws.Cell(r, 9).Value  = Math.Round(line.Qcalc_kVAR, 2);
                ws.Cell(r, 10).Value = Math.Round(line.Scalc_kVA, 2);

                // формулы вместо хардкода для Qр и Sр
                ws.Cell(r, 9).SetValue(
                    $"=F{r}*(SQRT(1-G{r}^2)/G{r})");
                ws.Cell(r, 10).SetValue(
                    $"=IF(G{r}>0,F{r}/G{r},F{r})");

                StyleDataRow(ws, r, 10, bg);
                lineNum++;
                row++;
            }

            // Строка: нераспознанные (если есть)
            if (settings.RevitData?.P_Unknown_W > 0)
            {
                double unkKw = settings.RevitData.P_Unknown_W / 1000.0;
                ws.Cell(row, 1).Value  = "!";
                ws.Cell(row, 2).Value  = "Нераспознанные нагрузки (уточнить категорию)";
                ws.Cell(row, 3).Value  = "см. лист «Детализация»";
                ws.Cell(row, 4).Value  = Math.Round(unkKw, 2);
                ws.Cell(row, 5).Value  = "—";
                ws.Cell(row, 6).Value  = "—";
                StyleDataRow(ws, row, 10, ClrUnknown);
                row++;
            }

            // ── Строка итого (Рр) до несовпадения ─────────────
            row++;
            ws.Cell(row, 2).Value  = "Итого установленных / расчётных до несовпадения";
            ws.Cell(row, 3).Value  = "—";
            ws.Cell(row, 4).Value  = Math.Round(calc.TotalPinstalled, 2);
            ws.Cell(row, 6).Value  = $"=SUM(F{dataStartRow}:F{row - 2})";
            ws.Cell(row, 9).Value  = $"=SUM(I{dataStartRow}:I{row - 2})";
            ws.Cell(row, 10).Value = $"=SUM(J{dataStartRow}:J{row - 2})";
            StyleDataRow(ws, row, 10, ClrTotal);
            ws.Row(row).Style.Font.Bold = true;
            row++;

            // ── Коэф. несовпадения ─────────────────────────────
            ws.Cell(row, 2).Value = "Коэффициент несовпадения максимумов К";
            ws.Cell(row, 3).Value = "§7.2.16, табл. 7.11";
            ws.Cell(row, 4).Value = calc.Kcoincidence;
            ws.Cell(row, 4).Style.Font.Bold = true;
            ws.Cell(row, 4).Style.Fill.BackgroundColor = ClrTotal;
            row++;

            // ── Итоговая строка ввода ──────────────────────────
            int kcRow = row - 1; // строка с Кс
            ws.Cell(row, 2).Value  = "ИТОГО НА ВВОДЕ (расчётная нагрузка)";
            ws.Cell(row, 3).Value  = "§7.2.16";
            ws.Cell(row, 6).Value  = $"=F{row - 2}*D{kcRow}";   // Рр = Рр_sum × Кс
            ws.Cell(row, 9).Value  = $"=I{row - 2}*D{kcRow}";   // Qр
            ws.Cell(row, 10).Value = $"=SQRT(F{row}^2+I{row}^2)"; // Sр
            ws.Cell(row, 7).Value  = $"=F{row}/J{row}";          // cosφ средн.
            StyleDataRow(ws, row, 10, ClrResult);
            ws.Row(row).Style.Font.Bold = true;
            ws.Row(row).Style.Font.FontSize = 11;
            row++;

            // ── Ток ввода ─────────────────────────────────────
            ws.Cell(row, 2).Value = "Расчётный ток на вводе, А (380 В)";
            ws.Cell(row, 3).Value = "Iр = Sр / (√3 × U)";
            ws.Cell(row, 10).Value = $"=J{row - 1}*1000/(SQRT(3)*380)";
            ws.Cell(row, 10).Style.NumberFormat.Format = "0.0";
            ws.Cell(row, 10).Style.Font.Bold = true;
            ws.Cell(row, 10).Style.Fill.BackgroundColor = ClrResult;

            // ── Рамки и форматирование чисел ──────────────────
            ws.Range(dataStartRow - 1, 1, row, 10)
              .Style.Border.OutsideBorder = XLBorderStyleValues.Medium;
            FormatNumberCols(ws, dataStartRow, row - 1, new[] { 4, 5, 6, 7, 8, 9, 10 });
        }

        // ════════════════════════════════════════════════════════
        //  Лист 2 — Детализация источников
        // ════════════════════════════════════════════════════════
        private static void BuildDetailSheet(IXLWorkbook wb,
            RevitLoadData data, LoadCalcSettings settings)
        {
            var ws = wb.Worksheets.Add("Детализация");
            ws.Column(1).Width = 8;
            ws.Column(2).Width = 60;
            ws.Column(3).Width = 20;

            int row = 1;
            ws.Cell(row, 1).Value = "Детализация нагрузок по элементам Revit";
            ws.Cell(row, 1).Style.Font.Bold = true;
            ws.Cell(row, 1).Style.Font.FontSize = 13;
            row += 2;

            var groups = new (string title, XLColor color, List<string> items, double totalW)[]
            {
                ("Освещение", ClrRowOdd,   data.LightingSources, data.P_Lighting_W),
                ("Розетки",   ClrRowEven,  data.SocketsSources,  data.P_Sockets_W),
                ("Силовое",   ClrTotal,    data.PowerSources,    data.P_Power_W),
                ("Лифты",     ClrResult,   data.LiftSources,     data.P_Lifts_W),
                ("! Нераспознанные", ClrUnknown, data.UnknownSources, data.P_Unknown_W),
            };

            foreach (var g in groups)
            {
                if (g.items == null || g.items.Count == 0) continue;

                ws.Cell(row, 1).Value = g.title;
                ws.Cell(row, 1).Style.Font.Bold = true;
                ws.Cell(row, 1).Style.Fill.BackgroundColor = ClrSubHeader;
                ws.Cell(row, 1).Style.Font.FontColor = XLColor.White;
                ws.Row(row).Height = 18;
                ws.Cell(row, 3).Value = $"Итого: {g.totalW / 1000.0:F2} кВт";
                ws.Cell(row, 3).Style.Font.Bold = true;
                ws.Cell(row, 3).Style.Fill.BackgroundColor = ClrSubHeader;
                ws.Cell(row, 3).Style.Font.FontColor = XLColor.White;
                row++;

                int n = 1;
                foreach (var src in g.items)
                {
                    ws.Cell(row, 1).Value = n++;
                    ws.Cell(row, 2).Value = src;
                    ws.Row(row).Style.Fill.BackgroundColor = g.color;
                    row++;
                }
                row++;
            }
        }

        // ════════════════════════════════════════════════════════
        //  Лист 3 — Справочные Ксп
        // ════════════════════════════════════════════════════════
        private static void BuildRefSheet(IXLWorkbook wb, LoadCalcResult calc)
        {
            var ws = wb.Worksheets.Add("Справка СП 256");
            ws.Column(1).Width = 40;
            ws.Column(2).Width = 12;

            int row = 1;
            ws.Cell(row, 1).Value = "Нормативные источники (СП 256.1325800.2016)";
            ws.Cell(row, 1).Style.Font.Bold = true;
            row += 2;

            var refs = new[]
            {
                ("Ксп освещения", "Табл. 7.6"),
                ("Ксп розеток (питающие сети)", "Табл. 7.7"),
                ("Ксп силовых сетей", "Табл. 7.8"),
                ("Ксп лифтов", "Табл. 7.4"),
                ("Коэф. несовпадения К", "§7.2.16, Табл. 7.11"),
                ("cosφ для типов нагрузок", "Табл. 7.12"),
                ("Расчётная нагрузка на вводе", "Формула (12)"),
            };

            foreach (var (desc, norm) in refs)
            {
                ws.Cell(row, 1).Value = desc;
                ws.Cell(row, 2).Value = norm;
                ws.Cell(row, 2).Style.Font.Bold = true;
                ws.Cell(row, 2).Style.Fill.BackgroundColor = ClrRowOdd;
                row++;
            }

            row += 2;
            ws.Cell(row, 1).Value = "Применённые коэффициенты:";
            ws.Cell(row, 1).Style.Font.Bold = true;
            row++;
            foreach (var line in calc.Lines)
            {
                ws.Cell(row, 1).Value = line.Name;
                ws.Cell(row, 2).Value = $"Ксп = {line.Ksp:F2}";
                row++;
            }
            ws.Cell(row, 1).Value = "Коэф. несовпадения К";
            ws.Cell(row, 2).Value = $"К = {calc.Kcoincidence:F2}";
        }

        // ════════════════════════════════════════════════════════
        //  Вспомогательные методы форматирования
        // ════════════════════════════════════════════════════════
        private static void SetMerge(IXLWorksheet ws, int r1, int c1, int r2, int c2,
            bool bold, int fontSize, XLAlignmentHorizontalValues hAlign,
            XLColor bgColor, XLColor fgColor)
        {
            var range = ws.Range(r1, c1, r2, c2);
            range.Merge();
            range.Style.Font.Bold       = bold;
            range.Style.Font.FontSize   = fontSize;
            range.Style.Font.FontColor  = fgColor;
            range.Style.Fill.BackgroundColor = bgColor;
            range.Style.Alignment.Horizontal = hAlign;
            range.Style.Alignment.Vertical   = XLAlignmentVerticalValues.Center;
            ws.Row(r1).Height = 22;
        }

        private static void WriteInfoRow(IXLWorksheet ws, int row,
            string label, string value)
        {
            ws.Cell(row, 1).Value = label;
            ws.Cell(row, 1).Style.Font.Bold = true;
            ws.Cell(row, 2).Value = value;
            ws.Range(row, 2, row, 10).Merge();
        }

        private static void StyleDataRow(IXLWorksheet ws, int row, int cols, XLColor bg)
        {
            var range = ws.Range(row, 1, row, cols);
            range.Style.Fill.BackgroundColor = bg;
            range.Style.Border.InsideBorder  = XLBorderStyleValues.Hair;
            range.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            range.Style.Alignment.Vertical   = XLAlignmentVerticalValues.Center;
            ws.Cell(row, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
        }

        private static void FormatNumberCols(IXLWorksheet ws,
            int startRow, int endRow, int[] cols)
        {
            foreach (int c in cols)
                ws.Range(startRow, c, endRow, c)
                  .Style.NumberFormat.Format = "#,##0.00";
        }

        private static string LineNormRef(LoadCategory cat) => cat switch
        {
            LoadCategory.Lighting => "Табл. 7.6",
            LoadCategory.Sockets  => "Табл. 7.7",
            LoadCategory.Power    => "Табл. 7.8 поз.5",
            LoadCategory.Lifts    => "Табл. 7.4",
            _                     => "—"
        };

        private static string BuildingTypeText(BuildingType bt) => bt switch
        {
            BuildingType.Office  => "Офисы / управление",
            BuildingType.Trade   => "Торговля",
            BuildingType.Food    => "Общественное питание",
            BuildingType.Hotel   => "Гостиницы",
            BuildingType.School  => "Учебные заведения",
            BuildingType.Culture => "Клубы / ДК",
            BuildingType.Cinema  => "Кинотеатры",
            BuildingType.ActHall => "Актовый/конференц-зал",
            _                    => "Прочие"
        };
    }
}
