namespace HvacCalc.Core.Models
{
    public enum EquipmentType
    {
        Fancoil,          // Фанкойл
        Convector,        // Конвектор водяной
        Radiator,         // Радиатор
        AirHandlingUnit,  // Приточная установка с калорифером
        ElectricHeater    // Электрический конвектор (запасной вариант)
    }

    /// <summary>
    /// Позиция каталога оборудования ОВ
    /// </summary>
    public class EquipmentItem
    {
        public string         Id           { get; set; }   // артикул
        public string         Manufacturer { get; set; }
        public string         Model        { get; set; }
        public EquipmentType  Type         { get; set; }

        // Тепловые характеристики (при стандартных условиях)
        public double QHeating       { get; set; }  // тепловая мощность отопления, Вт
        public double QCooling       { get; set; }  // мощность охлаждения, Вт (для фанкойлов)
        public double AirflowM3h    { get; set; }  // расход воздуха, м³/ч
        public double NoisedB       { get; set; }  // шум, дБА

        // Для воды
        public double WaterFlowLh   { get; set; }  // расход воды, л/ч
        public double PressureDropPa{ get; set; }  // потери давления, Па

        // Габариты
        public double Width  { get; set; }  // мм
        public double Height { get; set; }  // мм
        public double Depth  { get; set; }  // мм

        // Для отчёта
        public string ADSK_Name     { get; set; }  // ADSK_Наименование
        public string ADSK_Mark     { get; set; }  // ADSK_Марка
    }

    /// <summary>
    /// Результат подбора оборудования для одного помещения
    /// </summary>
    public class EquipmentSelection
    {
        public HeatLossResult Room        { get; set; }
        public EquipmentItem  Selected    { get; set; }
        public double         PowerRatio  { get; set; }  // Q_оборуд / Q_помещ
        public bool           IsOk        { get; set; }  // мощность достаточна
        public string         Note        { get; set; }  // замечания
    }
}
