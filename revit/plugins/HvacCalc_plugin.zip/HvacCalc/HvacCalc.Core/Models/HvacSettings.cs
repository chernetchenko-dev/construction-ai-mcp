namespace HvacCalc.Core.Models
{
    /// <summary>
    /// Настройки плагина — сохраняются в JSON рядом с .addin
    /// </summary>
    public class HvacSettings
    {
        // === Климат (СП 131.13330.2020) ===
        public string City           { get; set; } = "Санкт-Петербург";
        public double TExteriorDesign { get; set; } = -26.0;  // t_нар расч., параметр Б, °С
        public double TExteriorAvg5  { get; set; } = -15.0;  // средняя наиболее холодных 5 суток

        // === Внутренние условия (ГОСТ 30494) ===
        public double TInteriorDefault { get; set; } = 22.0;  // если параметр помещения не заполнен
        // Параметр Revit, откуда читать t_вн (имя параметра помещения)
        public string TInteriorParamName { get; set; } = "Расчётная температура";

        // === Источник данных об ограждениях ===
        public EnvelopeDataSource EnvelopeSource { get; set; } = EnvelopeDataSource.RevitWallTypes;
        // Имя параметра типа стены/перекрытия, где хранится R_ред (м²·°С/Вт)
        public string RReducedParamName { get; set; } = "ТТ_R_приведённое";
        // Значения по умолчанию для ручного ввода (если EnvelopeSource = ManualInput)
        public double RWallDefault     { get; set; } = 3.0;
        public double RWindowDefault   { get; set; } = 0.6;
        public double RRoofDefault     { get; set; } = 4.5;
        public double RFloorDefault    { get; set; } = 2.5;

        // === Надбавки (СП 60, прил. Б) ===
        public bool   UseOrientationBonus { get; set; } = true;
        public bool   UseAngularBonus     { get; set; } = true;
        public double MiscBonus           { get; set; } = 0.0;  // прочие надбавки, доля

        // === Инфильтрация ===
        public bool   CalcInfiltration    { get; set; } = true;
        public double InfiltrationCoeff   { get; set; } = 0.5;  // кратность инфильтрации, 1/ч

        // === Подбор оборудования ===
        // Какие типы оборудования участвуют в подборе
        public bool SelectFancoils   { get; set; } = true;
        public bool SelectConvectors { get; set; } = true;
        public bool SelectRadiators  { get; set; } = true;
        public bool SelectAHU        { get; set; } = false;
        public double OverpowerCoeff { get; set; } = 1.05;  // запас мощности

        // === Параметры Revit для записи результатов ===
        public string ResultParamHeatLoad { get; set; } = "ADSK_Тепловая нагрузка";
        public string ResultParamTemp     { get; set; } = "Расчётная температура";

        // === Отчёт ===
        public string ReportOutputPath   { get; set; } = "";  // пусто = рядом с .rvt
        public string ReportTemplate     { get; set; } = "Default";
        public string ProjectName        { get; set; } = "";
        public string ProjectCode        { get; set; } = "";
        public string Engineer           { get; set; } = "";
    }
}
