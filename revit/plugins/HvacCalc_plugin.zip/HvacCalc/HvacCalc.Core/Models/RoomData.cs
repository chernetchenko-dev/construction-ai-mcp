namespace HvacCalc.Core.Models
{
    /// <summary>
    /// Источник данных об ограждающих конструкциях помещения
    /// </summary>
    public enum EnvelopeDataSource
    {
        /// <summary>Читаем R_ред из параметров типов стен в Revit</summary>
        RevitWallTypes,
        /// <summary>Пользователь вводит R_ред вручную в диалоге настроек</summary>
        ManualInput
    }

    /// <summary>
    /// Данные об одном ограждении помещения
    /// </summary>
    public class EnvelopeSurface
    {
        public string Name { get; set; }          // "Наружная стена С", "Окно", "Пол"
        public double Area { get; set; }          // м²
        public double RReduced { get; set; }      // приведённое R, м²·°С/Вт
        public bool IsExterior { get; set; }      // выходит наружу
        public Orientation Orientation { get; set; }
    }

    public enum Orientation { N, NE, E, SE, S, SW, W, NW, None }

    /// <summary>
    /// Все данные по помещению, необходимые для расчёта Q
    /// </summary>
    public class RoomData
    {
        public int    RevitId    { get; set; }
        public string Name       { get; set; }
        public string Number     { get; set; }
        public int    Level      { get; set; }    // этаж

        // Температуры
        public double TInterior  { get; set; }    // t_вн, °С (из параметра помещения или ГОСТ 30494)
        public double TExterior  { get; set; }    // t_нар расч., °С (из СП 131 / настроек)

        // Геометрия
        public double Area       { get; set; }    // площадь пола, м²
        public double Height     { get; set; }    // высота, м
        public double Volume     { get; set; }    // объём, м³

        // Ограждения
        public System.Collections.Generic.List<EnvelopeSurface> Surfaces { get; set; }
            = new System.Collections.Generic.List<EnvelopeSurface>();

        // Инфильтрация
        public double InfiltrationAirflow { get; set; }  // м³/ч, 0 = не учитывать
    }
}
