using System.Collections.Generic;

namespace HvacCalc.Core.Models
{
    /// <summary>
    /// Результат расчёта теплопотерь одного помещения по СП 60.13330.2020, Прил. Б
    /// </summary>
    public class HeatLossResult
    {
        public int    RevitId    { get; set; }
        public string RoomName   { get; set; }
        public string RoomNumber { get; set; }

        // Составляющие теплопотерь, Вт
        public double QTransmission  { get; set; }  // через ограждения
        public double QInfiltration  { get; set; }  // на нагрев инфильтрующегося воздуха
        public double QAdditional    { get; set; }  // надбавки (ориентация, угловые)
        public double QTotal         { get; set; }  // итог (округлён до 10 Вт)

        // Детализация по ограждениям
        public List<SurfaceLoss> SurfaceDetails { get; set; } = new List<SurfaceLoss>();

        // Флаги
        public bool IsAngularRoom    { get; set; }  // угловое помещение (+5%)
        public double AddCoeffSum    { get; set; }  // сумма коэффициентов надбавок β
    }

    public class SurfaceLoss
    {
        public string SurfaceName  { get; set; }
        public double Area         { get; set; }   // м²
        public double RReduced     { get; set; }   // м²·°С/Вт
        public double DeltaT       { get; set; }   // t_вн - t_нар, °С
        public double Q            { get; set; }   // Вт, через данное ограждение
        public double Beta         { get; set; }   // надбавка по ориентации
    }
}
