using System;
using System.Collections.Generic;
using HvacCalc.Core.Models;

namespace HvacCalc.Core.Services
{
    /// <summary>
    /// Расчёт теплопотерь по СП 60.13330.2020, Приложение Б.
    /// Формула: Q = Σ[A_i / R_ред_i × ΔT_i × (1 + Σβ_i)] + Q_инф
    /// Не зависит от Revit API — тестируется независимо.
    /// </summary>
    public class HeatLossCalculator
    {
        private readonly HvacSettings _s;

        // Надбавки по ориентации (СП 60, табл. Б.3)
        private static readonly Dictionary<Orientation, double> OrientationBeta =
            new Dictionary<Orientation, double>
        {
            { Orientation.N,   0.10 },
            { Orientation.NE,  0.10 },
            { Orientation.NW,  0.10 },
            { Orientation.E,   0.05 },
            { Orientation.W,   0.05 },
            { Orientation.S,   0.00 },
            { Orientation.SE,  0.00 },
            { Orientation.SW,  0.00 },
            { Orientation.None,0.00 },
        };

        public HeatLossCalculator(HvacSettings settings)
        {
            _s = settings ?? throw new ArgumentNullException(nameof(settings));
        }

        public HeatLossResult Calculate(RoomData room)
        {
            if (room == null) throw new ArgumentNullException(nameof(room));

            double tIn  = room.TInterior;
            double tOut = room.TExterior;
            double dT   = tIn - tOut;

            var result = new HeatLossResult
            {
                RevitId    = room.RevitId,
                RoomName   = room.Name,
                RoomNumber = room.Number,
            };

            // Надбавка за угловое помещение
            bool isAngular = IsAngularRoom(room);
            result.IsAngularRoom = isAngular;

            // 1. Трансмиссионные теплопотери через каждое ограждение
            double qTrans = 0;
            foreach (var surf in room.Surfaces)
            {
                if (!surf.IsExterior) continue;
                if (surf.RReduced <= 0) continue;

                double beta = 0;
                if (_s.UseOrientationBonus)
                    beta += OrientationBeta[surf.Orientation];
                if (_s.UseAngularBonus && isAngular)
                    beta += 0.05;
                beta += _s.MiscBonus;

                double q = surf.Area / surf.RReduced * dT * (1 + beta);

                result.SurfaceDetails.Add(new SurfaceLoss
                {
                    SurfaceName = surf.Name,
                    Area        = surf.Area,
                    RReduced    = surf.RReduced,
                    DeltaT      = dT,
                    Q           = q,
                    Beta        = beta,
                });
                result.AddCoeffSum += beta;
                qTrans += q;
            }
            result.QTransmission = qTrans;

            // 2. Теплопотери на нагрев инфильтрующегося воздуха (СП 60, Б.11)
            // Q_инф = 0.278 × L_инф × ρ_н × c × (t_вн - t_нар), Вт
            // ρ_н ≈ 353 / (273 + t_нар), c = 1.005 кДж/(кг·°С)
            double qInfil = 0;
            if (_s.CalcInfiltration)
            {
                double airflowM3h = room.InfiltrationAirflow > 0
                    ? room.InfiltrationAirflow
                    : _s.InfiltrationCoeff * room.Volume;    // кратность × объём

                double rhoExt = 353.0 / (273.0 + tOut);     // кг/м³
                qInfil = 0.278 * airflowM3h * rhoExt * 1.005 * dT;
            }
            result.QInfiltration = qInfil;

            // 3. Итог — округление до 10 Вт (п. Б.12)
            double qRaw = qTrans + qInfil;
            result.QTotal = Math.Ceiling(qRaw / 10.0) * 10.0;

            return result;
        }

        // Помещение считается угловым, если имеет ≥ 2 наружных стены
        private static bool IsAngularRoom(RoomData room)
        {
            int extWalls = 0;
            foreach (var s in room.Surfaces)
            {
                if (s.IsExterior && s.Name != null &&
                    (s.Name.Contains("Стена") || s.Name.Contains("Wall")))
                    extWalls++;
            }
            return extWalls >= 2;
        }

        /// <summary>
        /// Рассчитать список помещений пакетно
        /// </summary>
        public List<HeatLossResult> CalculateAll(IEnumerable<RoomData> rooms)
        {
            var results = new List<HeatLossResult>();
            foreach (var r in rooms)
            {
                try   { results.Add(Calculate(r)); }
                catch (Exception ex)
                {
                    results.Add(new HeatLossResult
                    {
                        RevitId    = r.RevitId,
                        RoomName   = r.Name,
                        RoomNumber = r.Number,
                        QTotal     = 0,
                    });
                    System.Diagnostics.Debug.WriteLine(
                        $"HeatLoss ERROR room {r.Number}: {ex.Message}");
                }
            }
            return results;
        }
    }
}
