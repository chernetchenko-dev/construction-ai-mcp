using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HvacCalc.Core.Models;
using Newtonsoft.Json;

namespace HvacCalc.Core.Services
{
    /// <summary>
    /// Подбор оборудования по тепловой нагрузке.
    /// Каталог загружается из equipment_catalog.json рядом с .dll.
    /// </summary>
    public class EquipmentSelector
    {
        private readonly HvacSettings _s;
        private readonly List<EquipmentItem> _catalog;

        public EquipmentSelector(HvacSettings settings, string catalogPath = null)
        {
            _s = settings ?? throw new ArgumentNullException(nameof(settings));
            _catalog = LoadCatalog(catalogPath);
        }

        /// <summary>
        /// Подобрать оборудование для одного помещения.
        /// Возвращает минимально достаточную по мощности позицию каждого включённого типа.
        /// </summary>
        public EquipmentSelection Select(HeatLossResult room)
        {
            double qRequired = room.QTotal * _s.OverpowerCoeff;

            // Фильтруем каталог по включённым типам
            var allowed = AllowedTypes();
            var candidates = _catalog
                .Where(e => allowed.Contains(e.Type) && e.QHeating >= qRequired)
                .OrderBy(e => e.QHeating)   // берём минимально подходящий
                .ToList();

            if (candidates.Count == 0)
            {
                // Если ничего не нашли — вернуть самый мощный из каталога
                var biggest = _catalog
                    .Where(e => allowed.Contains(e.Type))
                    .OrderByDescending(e => e.QHeating)
                    .FirstOrDefault();

                return new EquipmentSelection
                {
                    Room       = room,
                    Selected   = biggest,
                    PowerRatio = biggest != null ? biggest.QHeating / room.QTotal : 0,
                    IsOk       = false,
                    Note       = $"Недостаточная мощность в каталоге. Требуется {qRequired:F0} Вт."
                };
            }

            var best = candidates.First();
            return new EquipmentSelection
            {
                Room       = room,
                Selected   = best,
                PowerRatio = best.QHeating / room.QTotal,
                IsOk       = true,
                Note       = ""
            };
        }

        public List<EquipmentSelection> SelectAll(IEnumerable<HeatLossResult> rooms)
            => rooms.Select(Select).ToList();

        private List<EquipmentType> AllowedTypes()
        {
            var list = new List<EquipmentType>();
            if (_s.SelectFancoils)   list.Add(EquipmentType.Fancoil);
            if (_s.SelectConvectors) list.Add(EquipmentType.Convector);
            if (_s.SelectRadiators)  list.Add(EquipmentType.Radiator);
            if (_s.SelectAHU)        list.Add(EquipmentType.AirHandlingUnit);
            return list;
        }

        // ──────────────────────────────────────────────────────────────
        // Загрузка каталога
        // ──────────────────────────────────────────────────────────────
        private static List<EquipmentItem> LoadCatalog(string path)
        {
            // Если путь не задан — ищем рядом с .dll
            if (string.IsNullOrEmpty(path))
            {
                string dll = typeof(EquipmentSelector).Assembly.Location;
                path = Path.Combine(Path.GetDirectoryName(dll), "equipment_catalog.json");
            }

            if (File.Exists(path))
            {
                try
                {
                    var json = File.ReadAllText(path, System.Text.Encoding.UTF8);
                    return JsonConvert.DeserializeObject<List<EquipmentItem>>(json)
                           ?? BuiltInCatalog();
                }
                catch
                {
                    return BuiltInCatalog();
                }
            }
            return BuiltInCatalog();
        }

        /// <summary>
        /// Встроенный минимальный каталог — на случай отсутствия JSON-файла.
        /// В реальном проекте заменяется полным JSON с данными производителей.
        /// </summary>
        private static List<EquipmentItem> BuiltInCatalog() => new List<EquipmentItem>
        {
            // Фанкойлы (Daikin-style)
            new EquipmentItem { Id="FCU-200", Manufacturer="Generic", Model="FCU-200",
                Type=EquipmentType.Fancoil, QHeating=2000, QCooling=1800,
                AirflowM3h=180, NoisedB=32, Width=800, Height=200, Depth=200 },
            new EquipmentItem { Id="FCU-500", Manufacturer="Generic", Model="FCU-500",
                Type=EquipmentType.Fancoil, QHeating=5000, QCooling=4500,
                AirflowM3h=420, NoisedB=36, Width=1200, Height=200, Depth=200 },
            new EquipmentItem { Id="FCU-900", Manufacturer="Generic", Model="FCU-900",
                Type=EquipmentType.Fancoil, QHeating=9000, QCooling=8000,
                AirflowM3h=720, NoisedB=40, Width=1800, Height=200, Depth=200 },

            // Конвекторы водяные
            new EquipmentItem { Id="CONV-1500", Manufacturer="Generic", Model="CONV-1500",
                Type=EquipmentType.Convector, QHeating=1500,
                Width=600, Height=400, Depth=120 },
            new EquipmentItem { Id="CONV-3000", Manufacturer="Generic", Model="CONV-3000",
                Type=EquipmentType.Convector, QHeating=3000,
                Width=1000, Height=400, Depth=120 },
            new EquipmentItem { Id="CONV-5500", Manufacturer="Generic", Model="CONV-5500",
                Type=EquipmentType.Convector, QHeating=5500,
                Width=1600, Height=400, Depth=120 },

            // Радиаторы (секционные)
            new EquipmentItem { Id="RAD-700", Manufacturer="Generic", Model="RAD-10sec",
                Type=EquipmentType.Radiator, QHeating=700,
                Width=600, Height=500, Depth=90 },
            new EquipmentItem { Id="RAD-2100", Manufacturer="Generic", Model="RAD-30sec",
                Type=EquipmentType.Radiator, QHeating=2100,
                Width=1800, Height=500, Depth=90 },
            new EquipmentItem { Id="RAD-4200", Manufacturer="Generic", Model="RAD-60sec",
                Type=EquipmentType.Radiator, QHeating=4200,
                Width=3600, Height=500, Depth=90 },

            // Приточные установки
            new EquipmentItem { Id="AHU-5000", Manufacturer="Generic", Model="AHU-5000",
                Type=EquipmentType.AirHandlingUnit, QHeating=5000, AirflowM3h=1000,
                Width=1200, Height=600, Depth=600 },
            new EquipmentItem { Id="AHU-15000", Manufacturer="Generic", Model="AHU-15000",
                Type=EquipmentType.AirHandlingUnit, QHeating=15000, AirflowM3h=3000,
                Width=2400, Height=800, Depth=800 },
        };

        public List<EquipmentItem> GetCatalog() => _catalog;
    }
}
