using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using HvacCalc.Core.Models;

namespace HvacCalc.Core.Services
{
    /// <summary>
    /// Формирует расчётную записку в формате HTML (открывается в браузере,
    /// печатается как PDF или Word через браузер).
    /// Не зависит от Revit API.
    /// </summary>
    public class ReportGenerator
    {
        private readonly HvacSettings _s;

        public ReportGenerator(HvacSettings settings)
        {
            _s = settings ?? throw new ArgumentNullException(nameof(settings));
        }

        public string GenerateHtml(
            List<HeatLossResult>     heatResults,
            List<EquipmentSelection> equipment,
            string                   projectFilePath)
        {
            var sb = new StringBuilder();
            string date = DateTime.Now.ToString("dd.MM.yyyy");
            double totalQ = heatResults.Sum(r => r.QTotal);

            sb.AppendLine("<!DOCTYPE html><html lang='ru'><head>");
            sb.AppendLine("<meta charset='UTF-8'>");
            sb.AppendLine("<title>Расчётная записка ОВиК</title>");
            sb.AppendLine(Css());
            sb.AppendLine("</head><body>");

            // Титул
            sb.AppendLine("<div class='title-block'>");
            sb.AppendLine($"<h1>Расчётная записка</h1>");
            sb.AppendLine($"<h2>Раздел ОВиК. Расчёт тепловых нагрузок</h2>");
            sb.AppendLine($"<table class='meta'>");
            sb.AppendLine($"<tr><td>Объект:</td><td>{Esc(_s.ProjectName)}</td></tr>");
            sb.AppendLine($"<tr><td>Шифр:</td><td>{Esc(_s.ProjectCode)}</td></tr>");
            sb.AppendLine($"<tr><td>Инженер:</td><td>{Esc(_s.Engineer)}</td></tr>");
            sb.AppendLine($"<tr><td>Дата:</td><td>{date}</td></tr>");
            sb.AppendLine($"<tr><td>Файл Revit:</td><td>{Esc(Path.GetFileName(projectFilePath))}</td></tr>");
            sb.AppendLine("</table></div>");

            // Нормативная база
            sb.AppendLine("<h2>1. Нормативная база</h2><ul>");
            sb.AppendLine("<li>СП 60.13330.2020 «Отопление, вентиляция и кондиционирование воздуха»</li>");
            sb.AppendLine("<li>СП 131.13330.2020 «Строительная климатология»</li>");
            sb.AppendLine("<li>СП 50.13330.2012 «Тепловая защита зданий»</li>");
            sb.AppendLine("<li>ГОСТ 30494-2011 «Здания жилые и общественные. Параметры микроклимата»</li>");
            sb.AppendLine("</ul>");

            // Исходные данные
            sb.AppendLine("<h2>2. Исходные данные</h2>");
            sb.AppendLine("<table class='data'>");
            sb.AppendLine($"<tr><td>Город</td><td>{Esc(_s.City)}</td></tr>");
            sb.AppendLine($"<tr><td>Расчётная температура наружного воздуха (параметр Б), °С</td><td>{_s.TExteriorDesign}</td></tr>");
            sb.AppendLine($"<tr><td>Расчётная температура внутри (по умолчанию), °С</td><td>{_s.TInteriorDefault}</td></tr>");
            sb.AppendLine($"<tr><td>Источник данных об ограждениях</td><td>{(_s.EnvelopeSource == EnvelopeDataSource.RevitWallTypes ? "Параметры типов конструкций Revit" : "Ручной ввод")}</td></tr>");
            sb.AppendLine($"<tr><td>Учёт инфильтрации</td><td>{(_s.CalcInfiltration ? "Да" : "Нет")}</td></tr>");
            sb.AppendLine($"<tr><td>Запас мощности оборудования</td><td>{_s.OverpowerCoeff:P0}</td></tr>");
            sb.AppendLine("</table>");

            // Сводная таблица теплопотерь
            sb.AppendLine("<h2>3. Сводная таблица теплопотерь</h2>");
            sb.AppendLine("<table class='results'>");
            sb.AppendLine("<thead><tr>");
            sb.AppendLine("<th>№</th><th>Помещение</th><th>Q_огр, Вт</th><th>Q_инф, Вт</th><th>Q_итог, Вт</th><th>Оборудование</th><th>Q_обор, Вт</th>");
            sb.AppendLine("</tr></thead><tbody>");

            int idx = 1;
            foreach (var r in heatResults.OrderBy(x => x.RoomNumber))
            {
                var eq = equipment?.FirstOrDefault(e => e.Room?.RevitId == r.RevitId);
                string eqName = eq?.Selected != null
                    ? $"{eq.Selected.Manufacturer} {eq.Selected.Model}"
                    : "—";
                string eqQ = eq?.Selected != null ? $"{eq.Selected.QHeating:F0}" : "—";
                string warn = eq?.IsOk == false ? " ⚠" : "";

                sb.AppendLine($"<tr>");
                sb.AppendLine($"<td>{idx++}</td>");
                sb.AppendLine($"<td>{Esc(r.RoomNumber)} {Esc(r.RoomName)}</td>");
                sb.AppendLine($"<td>{r.QTransmission:F0}</td>");
                sb.AppendLine($"<td>{r.QInfiltration:F0}</td>");
                sb.AppendLine($"<td class='bold'>{r.QTotal:F0}</td>");
                sb.AppendLine($"<td>{Esc(eqName)}{warn}</td>");
                sb.AppendLine($"<td>{eqQ}</td>");
                sb.AppendLine("</tr>");
            }

            sb.AppendLine($"<tr class='total'><td colspan='4'><b>ИТОГО</b></td>");
            sb.AppendLine($"<td class='bold'>{totalQ:F0}</td><td colspan='2'></td></tr>");
            sb.AppendLine("</tbody></table>");

            // Детализация по помещениям
            sb.AppendLine("<h2>4. Детализация по помещениям</h2>");
            foreach (var r in heatResults.OrderBy(x => x.RoomNumber))
            {
                sb.AppendLine($"<h3>Помещение {Esc(r.RoomNumber)} «{Esc(r.RoomName)}»</h3>");
                sb.AppendLine("<table class='data'>");
                sb.AppendLine("<thead><tr><th>Ограждение</th><th>A, м²</th><th>R_ред, м²·°С/Вт</th><th>ΔT, °С</th><th>β</th><th>Q, Вт</th></tr></thead><tbody>");
                foreach (var surf in r.SurfaceDetails)
                {
                    sb.AppendLine($"<tr><td>{Esc(surf.SurfaceName)}</td><td>{surf.Area:F2}</td>" +
                        $"<td>{surf.RReduced:F3}</td><td>{surf.DeltaT:F1}</td>" +
                        $"<td>{surf.Beta:F2}</td><td>{surf.Q:F1}</td></tr>");
                }
                sb.AppendLine($"<tr><td colspan='5'>Инфильтрация</td><td>{r.QInfiltration:F1}</td></tr>");
                sb.AppendLine($"<tr class='total'><td colspan='5'><b>Итого</b></td><td><b>{r.QTotal:F0}</b></td></tr>");
                sb.AppendLine("</tbody></table>");
            }

            sb.AppendLine("<p class='footer'>Расчёт выполнен плагином HvacCalc для Autodesk Revit. " +
                          $"Дата: {date}</p>");
            sb.AppendLine("</body></html>");
            return sb.ToString();
        }

        public string SaveReport(
            List<HeatLossResult>     heatResults,
            List<EquipmentSelection> equipment,
            string                   projectFilePath)
        {
            string dir = string.IsNullOrEmpty(_s.ReportOutputPath)
                ? Path.GetDirectoryName(projectFilePath)
                : _s.ReportOutputPath;

            string fileName = $"OVK_Report_{DateTime.Now:yyyyMMdd_HHmm}.html";
            string fullPath = Path.Combine(dir, fileName);
            string html = GenerateHtml(heatResults, equipment, projectFilePath);
            File.WriteAllText(fullPath, html, Encoding.UTF8);
            return fullPath;
        }

        private static string Esc(string s) =>
            System.Web.HttpUtility.HtmlEncode(s ?? "");

        private static string Css() => @"<style>
body{font-family:'Arial',sans-serif;font-size:11pt;margin:20mm 15mm;color:#111}
h1{font-size:16pt;text-align:center;margin-bottom:4px}
h2{font-size:13pt;margin-top:20px;border-bottom:1px solid #999;padding-bottom:3px}
h3{font-size:11pt;margin-top:14px;color:#2a4a8a}
.title-block{text-align:center;margin-bottom:24px}
table{border-collapse:collapse;width:100%;margin-bottom:12px}
th,td{border:1px solid #bbb;padding:4px 8px;font-size:10pt}
th{background:#e8edf5;font-weight:bold;text-align:center}
table.meta{width:auto;min-width:400px;margin:0 auto}
table.meta td:first-child{font-weight:bold;white-space:nowrap}
.bold{font-weight:bold}
.total{background:#f0f0f0;font-weight:bold}
.footer{margin-top:24px;font-size:9pt;color:#666;text-align:center}
@media print{h2{page-break-before:always}h2:first-of-type{page-break-before:avoid}}
</style>";
    }
}
