using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using HvacCalc.Core.Models;

namespace HvacCalc.RevitBridge
{
    /// <summary>
    /// Записывает результаты расчёта обратно в параметры помещений Revit.
    /// Все изменения выполняются в одной транзакции.
    /// </summary>
    public class RevitWriter
    {
        private readonly Document   _doc;
        private readonly HvacSettings _s;

        public RevitWriter(Document doc, HvacSettings settings)
        {
            _doc = doc ?? throw new ArgumentNullException(nameof(doc));
            _s   = settings ?? throw new ArgumentNullException(nameof(settings));
        }

        /// <summary>
        /// Записать Q_итого в параметр каждого помещения.
        /// Возвращает количество успешно записанных помещений.
        /// </summary>
        public int WriteHeatLoss(IEnumerable<HeatLossResult> results)
        {
            int count = 0;
            using (var t = new Transaction(_doc, "HvacCalc: Запись тепловых нагрузок"))
            {
                t.Start();
                foreach (var r in results)
                {
                    if (TryWriteHeatLoss(r)) count++;
                }
                t.Commit();
            }
            return count;
        }

        private bool TryWriteHeatLoss(HeatLossResult r)
        {
            var room = _doc.GetElement(new ElementId(r.RevitId)) as Room;
            if (room == null) return false;

            // Записываем Q_итого
            bool ok = SetParameter(room, _s.ResultParamHeatLoad, r.QTotal);

            // Дополнительно — компоненты для диагностики
            SetParameterIfExists(room, "ОВ_Q_трансмиссионные", r.QTransmission);
            SetParameterIfExists(room, "ОВ_Q_инфильтрация",    r.QInfiltration);

            return ok;
        }

        private bool SetParameter(Element elem, string paramName, double value)
        {
            var p = elem.LookupParameter(paramName);
            if (p == null || p.IsReadOnly) return false;

            switch (p.StorageType)
            {
                case StorageType.Double: return p.Set(value) == 1;
                case StorageType.String: return p.Set(value.ToString("F0")) == 1;
                case StorageType.Integer: return p.Set((int)Math.Round(value)) == 1;
                default: return false;
            }
        }

        private void SetParameterIfExists(Element elem, string paramName, double value)
        {
            try { SetParameter(elem, paramName, value); }
            catch { /* параметр необязателен */ }
        }

        /// <summary>
        /// Записать результаты подбора оборудования в параметры семейств в помещении.
        /// Ищет первый MEP-элемент в помещении и обновляет ADSK_Тепловая мощность.
        /// </summary>
        public int WriteEquipmentSelection(IEnumerable<EquipmentSelection> selections)
        {
            int count = 0;
            using (var t = new Transaction(_doc, "HvacCalc: Запись параметров оборудования"))
            {
                t.Start();
                foreach (var sel in selections)
                {
                    if (sel.Selected == null) continue;
                    if (WriteEquipmentToRoom(sel)) count++;
                }
                t.Commit();
            }
            return count;
        }

        private bool WriteEquipmentToRoom(EquipmentSelection sel)
        {
            var room = _doc.GetElement(new ElementId(sel.Room.RevitId)) as Room;
            if (room == null) return false;

            // Найти MEP-оборудование в этом помещении
            var collector = new FilteredElementCollector(_doc)
                .OfCategory(BuiltInCategory.OST_MechanicalEquipment)
                .WhereElementIsNotElementType();

            foreach (Element eq in collector)
            {
                var locPt = (eq.Location as LocationPoint)?.Point;
                if (locPt == null) continue;
                if (room.IsPointInRoom(locPt))
                {
                    SetParameterIfExists(eq, "ADSK_\u0422\u0435\u043f\u043b\u043e\u0432\u0430\u044f \u043c\u043e\u0449\u043d\u043e\u0441\u0442\u044c",
                        sel.Selected.QHeating);
                    SetParameterIfExists(eq, "ADSK_\u041c\u0430\u0440\u043a\u0430",
                        0); // строковый — обработается как SetParameter с value→string
                    return true;
                }
            }
            return false;
        }
    }
}
