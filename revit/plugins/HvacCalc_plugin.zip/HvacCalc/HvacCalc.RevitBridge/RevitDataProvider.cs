using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using HvacCalc.Core.Models;

namespace HvacCalc.RevitBridge
{
    /// <summary>
    /// Адаптер: Revit API → HvacCalc.Core.Models.
    /// Читает помещения (Room) и их ограждения из документа Revit.
    /// </summary>
    public class RevitDataProvider
    {
        private readonly Document      _doc;
        private readonly Core.Models.HvacSettings _s;

        // 1 фут = 0.3048 м; площадь: кв.фут → м²
        private const double Ft  = 0.3048;
        private const double Ft2 = Ft * Ft;

        public RevitDataProvider(Document doc, Core.Models.HvacSettings settings)
        {
            _doc = doc ?? throw new ArgumentNullException(nameof(doc));
            _s   = settings ?? throw new ArgumentNullException(nameof(settings));
        }

        /// <summary>
        /// Получить данные по всем помещениям в проекте (Area > 0, размещённые).
        /// </summary>
        public List<RoomData> GetAllRooms()
        {
            var rooms = new FilteredElementCollector(_doc)
                .OfCategory(BuiltInCategory.OST_Rooms)
                .WhereElementIsNotElementType()
                .Cast<Room>()
                .Where(r => r.Area > 0)   // исключаем «лишние» помещения
                .ToList();

            var result = new List<RoomData>();
            foreach (var room in rooms)
            {
                try   { result.Add(ConvertRoom(room)); }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(
                        $"RevitDataProvider: skip room {room.Id} — {ex.Message}");
                }
            }
            return result;
        }

        private RoomData ConvertRoom(Room room)
        {
            var rd = new RoomData
            {
                RevitId = room.Id.IntegerValue,
                Name    = room.Name ?? "",
                Number  = GetStringParam(room, BuiltInParameter.ROOM_NUMBER),
                Area    = room.Area * Ft2,
                Height  = room.UnboundedHeight * Ft,
                Volume  = room.Volume * Ft2 * Ft,
            };

            // Температура внутри
            rd.TInterior = GetRoomTemperature(room);
            // Температура снаружи — из настроек (единая для проекта)
            rd.TExterior = _s.TExteriorDesign;

            // Ограждающие конструкции
            rd.Surfaces = GetSurfaces(room);

            // Инфильтрация (если задана кратностью — вычислим в Calculator)
            rd.InfiltrationAirflow = 0;  // 0 = Calculator использует кратность

            return rd;
        }

        // ──────────────────────────────────────────────────────────────
        // Температура помещения
        // ──────────────────────────────────────────────────────────────
        private double GetRoomTemperature(Room room)
        {
            // Сначала пробуем параметр по имени из настроек
            var p = room.LookupParameter(_s.TInteriorParamName);
            if (p != null && p.StorageType == StorageType.Double && p.AsDouble() != 0)
                return p.AsDouble();   // Revit хранит температуру в °С (не в Кельвинах)

            // Fallback — значение по умолчанию из настроек
            return _s.TInteriorDefault;
        }

        // ──────────────────────────────────────────────────────────────
        // Ограждающие конструкции помещения
        // ──────────────────────────────────────────────────────────────
        private List<EnvelopeSurface> GetSurfaces(Room room)
        {
            var surfaces = new List<EnvelopeSurface>();

            // Получаем граничные элементы помещения
            var calculator = new SpatialElementGeometryCalculator(_doc);
            SpatialElementGeometryResults results;
            try   { results = calculator.CalculateSpatialElementGeometry(room); }
            catch { return surfaces; }

            var geom = results.GetGeometry();
            foreach (Face face in geom.Faces)
            {
                IList<SpatialElementBoundarySubface> bsf;
                try   { bsf = results.GetBoundaryFaceInfo(face); }
                catch { continue; }

                foreach (var sub in bsf)
                {
                    var surf = BuildSurface(sub, face);
                    if (surf != null) surfaces.Add(surf);
                }
            }
            return surfaces;
        }

        private EnvelopeSurface BuildSurface(SpatialElementBoundarySubface sub, Face face)
        {
            var bElem = sub.SpatialBoundaryElement;
            if (bElem == null) return null;

            Element elem = _doc.GetElement(bElem.HostElementId);
            if (elem == null) return null;

            double areaSqFt = sub.GetSubface().Area;
            if (areaSqFt < 0.01) return null;

            bool isExterior = false;
            string name     = elem.Name ?? "Ограждение";
            double rReduced = GetRReduced(elem, out isExterior);

            return new EnvelopeSurface
            {
                Name        = name,
                Area        = areaSqFt * Ft2,
                RReduced    = rReduced,
                IsExterior  = isExterior,
                Orientation = GetOrientation(face),
            };
        }

        // ──────────────────────────────────────────────────────────────
        // R_приведённое ограждения
        // ──────────────────────────────────────────────────────────────
        private double GetRReduced(Element elem, out bool isExterior)
        {
            isExterior = false;
            ElementType type = _doc.GetElement(elem.GetTypeId()) as ElementType;

            if (_s.EnvelopeSource == EnvelopeDataSource.RevitWallTypes && type != null)
            {
                // Читаем из параметра типа
                var p = type.LookupParameter(_s.RReducedParamName);
                if (p != null && p.StorageType == StorageType.Double && p.AsDouble() > 0)
                {
                    isExterior = IsExteriorElement(elem);
                    return p.AsDouble();
                }
            }

            // Ручной ввод / fallback — по категории элемента
            return GetDefaultR(elem, out isExterior);
        }

        private double GetDefaultR(Element elem, out bool isExterior)
        {
            isExterior = false;
            var cat = elem.Category?.BuiltInCategory;
            switch (cat)
            {
                case BuiltInCategory.OST_Walls:
                    isExterior = IsExteriorElement(elem);
                    return isExterior ? _s.RWallDefault : 0;   // внутренние стены — 0 (не учитываем)
                case BuiltInCategory.OST_Windows:
                case BuiltInCategory.OST_Doors:
                    isExterior = true;
                    return _s.RWindowDefault;
                case BuiltInCategory.OST_Roofs:
                    isExterior = true;
                    return _s.RRoofDefault;
                case BuiltInCategory.OST_Floors:
                    isExterior = IsExteriorElement(elem);
                    return isExterior ? _s.RFloorDefault : 0;
                default:
                    return 0;
            }
        }

        private static bool IsExteriorElement(Element elem)
        {
            if (elem is Wall wall)
            {
                var funcParam = wall.WallType?.get_Parameter(
                    BuiltInParameter.FUNCTION_PARAM);
                if (funcParam != null)
                {
                    int val = funcParam.AsInteger();
                    // 0 = Interior, 1 = Exterior, 2 = Foundation, 3 = Retaining, 4 = Soffit, 5 = Core-shaft
                    return val == 1;
                }
            }
            // Для перекрытий, крыш — считаем наружными
            return elem is Floor || elem is RoofBase;
        }

        // ──────────────────────────────────────────────────────────────
        // Ориентация по нормали грани
        // ──────────────────────────────────────────────────────────────
        private static Orientation GetOrientation(Face face)
        {
            try
            {
                var norm = face.ComputeNormal(new UV(0.5, 0.5));
                double angle = Math.Atan2(norm.X, norm.Y) * 180 / Math.PI;
                if (angle < 0) angle += 360;

                if (angle >= 337.5 || angle < 22.5)  return Orientation.N;
                if (angle < 67.5)  return Orientation.NE;
                if (angle < 112.5) return Orientation.E;
                if (angle < 157.5) return Orientation.SE;
                if (angle < 202.5) return Orientation.S;
                if (angle < 247.5) return Orientation.SW;
                if (angle < 292.5) return Orientation.W;
                return Orientation.NW;
            }
            catch { return Orientation.None; }
        }

        private static string GetStringParam(Element e, BuiltInParameter bip)
        {
            var p = e.get_Parameter(bip);
            return p?.AsString() ?? "";
        }
    }
}
