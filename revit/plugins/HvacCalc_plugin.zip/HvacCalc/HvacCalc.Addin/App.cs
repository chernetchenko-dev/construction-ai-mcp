using System;
using System.IO;
using System.Reflection;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using HvacCalc.Core.Models;
using Newtonsoft.Json;

namespace HvacCalc.Addin
{
    /// <summary>
    /// Точка входа .addin — регистрирует Ribbon при запуске Revit.
    /// </summary>
    public class App : IExternalApplication
    {
        internal static HvacSettings Settings { get; private set; }
        internal static string       AssemblyDir { get; private set; }
        internal static string       SettingsPath { get; private set; }

        public Result OnStartup(UIControlledApplication app)
        {
            AssemblyDir  = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            SettingsPath = Path.Combine(AssemblyDir, "hvaccalc_settings.json");
            Settings     = LoadSettings();

            try
            {
                BuildRibbon(app);
                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("HvacCalc", $"Ошибка загрузки плагина:\n{ex.Message}");
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication app)
        {
            SaveSettings(Settings);
            return Result.Succeeded;
        }

        // ──────────────────────────────────────────────────────────────
        // Ribbon
        // ──────────────────────────────────────────────────────────────
        private void BuildRibbon(UIControlledApplication app)
        {
            const string tabName   = "ОВиК Расчёт";
            const string panelName = "Тепловой расчёт";
            string dll = Assembly.GetExecutingAssembly().Location;

            app.CreateRibbonTab(tabName);
            RibbonPanel panel = app.CreateRibbonPanel(tabName, panelName);

            // 1. Теплопотери
            panel.AddItem(new PushButtonData(
                "CmdHeatLoss",
                "Теплопотери",
                dll,
                "HvacCalc.Addin.Commands.CmdHeatLoss")
            {
                ToolTip = "Рассчитать теплопотери всех помещений по СП 60",
                LargeImage = LoadIcon("heat.png"),
            });

            panel.AddSeparator();

            // 2. Подбор оборудования
            panel.AddItem(new PushButtonData(
                "CmdEquipment",
                "Оборудование",
                dll,
                "HvacCalc.Addin.Commands.CmdEquipment")
            {
                ToolTip = "Подобрать оборудование ОВ по рассчитанным теплопотерям",
                LargeImage = LoadIcon("equipment.png"),
            });

            // 3. Записать в модель
            panel.AddItem(new PushButtonData(
                "CmdWriteParams",
                "Записать\nв модель",
                dll,
                "HvacCalc.Addin.Commands.CmdWriteParams")
            {
                ToolTip = "Записать результаты расчёта в параметры помещений и оборудования",
                LargeImage = LoadIcon("write.png"),
            });

            panel.AddSeparator();

            // 4. Отчёт
            panel.AddItem(new PushButtonData(
                "CmdReport",
                "Расчётная\nзаписка",
                dll,
                "HvacCalc.Addin.Commands.CmdReport")
            {
                ToolTip = "Сформировать расчётную записку в формате HTML",
                LargeImage = LoadIcon("report.png"),
            });

            panel.AddSeparator();

            // 5. Настройки
            panel.AddItem(new PushButtonData(
                "CmdSettings",
                "Настройки",
                dll,
                "HvacCalc.Addin.Commands.CmdSettings")
            {
                ToolTip = "Настройки плагина: климат, источник данных, параметры",
                LargeImage = LoadIcon("settings.png"),
            });
        }

        private System.Windows.Media.ImageSource LoadIcon(string fileName)
        {
            try
            {
                string path = Path.Combine(AssemblyDir, "Resources", fileName);
                if (!File.Exists(path)) return null;
                var bmp = new System.Windows.Media.Imaging.BitmapImage(new Uri(path));
                return bmp;
            }
            catch { return null; }
        }

        // ──────────────────────────────────────────────────────────────
        // Настройки (JSON)
        // ──────────────────────────────────────────────────────────────
        internal static HvacSettings LoadSettings()
        {
            if (File.Exists(SettingsPath))
            {
                try
                {
                    var json = File.ReadAllText(SettingsPath, System.Text.Encoding.UTF8);
                    return JsonConvert.DeserializeObject<HvacSettings>(json) ?? new HvacSettings();
                }
                catch { }
            }
            return new HvacSettings();
        }

        internal static void SaveSettings(HvacSettings s)
        {
            try
            {
                var json = JsonConvert.SerializeObject(s, Formatting.Indented);
                File.WriteAllText(SettingsPath, json, System.Text.Encoding.UTF8);
            }
            catch { }
        }
    }
}
