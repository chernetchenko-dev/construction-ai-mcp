using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using HvacCalc.Core.Models;
using HvacCalc.Core.Services;
using HvacCalc.RevitBridge;

namespace HvacCalc.Addin.Commands
{
    // ══════════════════════════════════════════════════════════════════
    // 1. РАСЧЁТ ТЕПЛОПОТЕРЬ
    // ══════════════════════════════════════════════════════════════════
    [Transaction(TransactionMode.ReadOnly)]
    public class CmdHeatLoss : IExternalCommand
    {
        public Result Execute(ExternalCommandData cd, ref string msg, ElementSet els)
        {
            var doc = cd.Application.ActiveUIDocument.Document;
            var s   = App.Settings;

            try
            {
                var provider   = new RevitDataProvider(doc, s);
                var calculator = new HeatLossCalculator(s);

                var rooms   = provider.GetAllRooms();
                if (rooms.Count == 0)
                {
                    TaskDialog.Show("Теплопотери", "Не найдено ни одного помещения с площадью > 0.");
                    return Result.Cancelled;
                }

                var results = calculator.CalculateAll(rooms);

                // Сохраняем в сессии плагина для использования другими командами
                Session.HeatLossResults = results;
                Session.RoomData       = rooms;

                // Показываем краткую сводку
                double total = 0;
                foreach (var r in results) total += r.QTotal;

                TaskDialog dlg = new TaskDialog("Теплопотери — результат");
                dlg.MainInstruction = $"Рассчитано {results.Count} помещений";
                dlg.MainContent =
                    $"Суммарные теплопотери: {total:F0} Вт ({total/1000:F1} кВт)\n\n" +
                    $"Используйте команды «Оборудование», «Записать в модель» и «Расчётная записка».";
                dlg.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                return Result.Failed;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // 2. ПОДБОР ОБОРУДОВАНИЯ
    // ══════════════════════════════════════════════════════════════════
    [Transaction(TransactionMode.ReadOnly)]
    public class CmdEquipment : IExternalCommand
    {
        public Result Execute(ExternalCommandData cd, ref string msg, ElementSet els)
        {
            if (Session.HeatLossResults == null || Session.HeatLossResults.Count == 0)
            {
                TaskDialog.Show("Оборудование",
                    "Сначала выполните расчёт теплопотерь (кнопка «Теплопотери»).");
                return Result.Cancelled;
            }

            try
            {
                var s        = App.Settings;
                string catPath = Path.Combine(App.AssemblyDir, "equipment_catalog.json");
                var selector = new EquipmentSelector(s, catPath);
                var selected = selector.SelectAll(Session.HeatLossResults);

                Session.EquipmentSelections = selected;

                int ok   = 0;
                int warn = 0;
                foreach (var sel in selected)
                {
                    if (sel.IsOk) ok++;
                    else warn++;
                }

                TaskDialog dlg = new TaskDialog("Подбор оборудования — результат");
                dlg.MainInstruction = $"Подобрано оборудование для {selected.Count} помещений";
                dlg.MainContent =
                    $"Успешно: {ok}   Требуют внимания (⚠): {warn}\n\n" +
                    "Запишите результаты в модель кнопкой «Записать в модель».";
                dlg.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                return Result.Failed;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // 3. ЗАПИСЬ В МОДЕЛЬ
    // ══════════════════════════════════════════════════════════════════
    [Transaction(TransactionMode.Manual)]
    public class CmdWriteParams : IExternalCommand
    {
        public Result Execute(ExternalCommandData cd, ref string msg, ElementSet els)
        {
            if (Session.HeatLossResults == null || Session.HeatLossResults.Count == 0)
            {
                TaskDialog.Show("Запись",
                    "Нет результатов для записи. Выполните расчёт теплопотерь.");
                return Result.Cancelled;
            }

            var doc    = cd.Application.ActiveUIDocument.Document;
            var writer = new RevitWriter(doc, App.Settings);

            try
            {
                int writtenHL = writer.WriteHeatLoss(Session.HeatLossResults);

                int writtenEq = 0;
                if (Session.EquipmentSelections?.Count > 0)
                    writtenEq = writer.WriteEquipmentSelection(Session.EquipmentSelections);

                TaskDialog.Show("Запись в модель",
                    $"Записаны тепловые нагрузки: {writtenHL} помещений\n" +
                    $"Обновлены параметры оборудования: {writtenEq} эл.");

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                return Result.Failed;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // 4. РАСЧЁТНАЯ ЗАПИСКА
    // ══════════════════════════════════════════════════════════════════
    [Transaction(TransactionMode.ReadOnly)]
    public class CmdReport : IExternalCommand
    {
        public Result Execute(ExternalCommandData cd, ref string msg, ElementSet els)
        {
            if (Session.HeatLossResults == null || Session.HeatLossResults.Count == 0)
            {
                TaskDialog.Show("Расчётная записка",
                    "Нет данных для отчёта. Выполните расчёт теплопотерь.");
                return Result.Cancelled;
            }

            var doc = cd.Application.ActiveUIDocument.Document;
            var s   = App.Settings;

            try
            {
                // Имя проекта из документа, если не задано в настройках
                if (string.IsNullOrEmpty(s.ProjectName))
                    s.ProjectName = doc.Title;

                var generator = new ReportGenerator(s);
                string path = generator.SaveReport(
                    Session.HeatLossResults,
                    Session.EquipmentSelections,
                    doc.PathName);

                TaskDialog dlg = new TaskDialog("Расчётная записка");
                dlg.MainInstruction = "Расчётная записка сформирована";
                dlg.MainContent = path;
                dlg.AddCommandLink(TaskDialogCommandLinkId.CommandLink1, "Открыть в браузере");
                var res = dlg.Show();
                if (res == TaskDialogResult.CommandLink1)
                    Process.Start(path);

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                return Result.Failed;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // 5. НАСТРОЙКИ
    // ══════════════════════════════════════════════════════════════════
    [Transaction(TransactionMode.ReadOnly)]
    public class CmdSettings : IExternalCommand
    {
        public Result Execute(ExternalCommandData cd, ref string msg, ElementSet els)
        {
            var dlg = new UI.SettingsWindow(App.Settings);
            bool? result = dlg.ShowDialog();
            if (result == true)
            {
                App.Settings = dlg.Result;
                App.SaveSettings(App.Settings);
                // Сбрасываем кэшированные результаты — настройки изменились
                Session.HeatLossResults     = null;
                Session.EquipmentSelections = null;
            }
            return Result.Succeeded;
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Сессионный кэш результатов (живёт пока открыт Revit)
    // ══════════════════════════════════════════════════════════════════
    internal static class Session
    {
        public static List<RoomData>           RoomData            { get; set; }
        public static List<HeatLossResult>     HeatLossResults     { get; set; }
        public static List<EquipmentSelection> EquipmentSelections { get; set; }
    }
}
