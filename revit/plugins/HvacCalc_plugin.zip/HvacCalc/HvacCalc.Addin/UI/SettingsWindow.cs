using System.Windows;
using System.Windows.Controls;
using HvacCalc.Core.Models;

namespace HvacCalc.Addin.UI
{
    /// <summary>
    /// Диалог настроек плагина (WPF).
    /// XAML генерируется кодом для минимизации зависимостей.
    /// </summary>
    public class SettingsWindow : Window
    {
        public HvacSettings Result { get; private set; }
        private readonly HvacSettings _original;

        // Контролы
        private TextBox  _tbCity, _tbTExt, _tbTInt, _tbRWall, _tbRWin, _tbRRoof, _tbRFloor;
        private TextBox  _tbRParam, _tbTParam, _tbOverpower;
        private TextBox  _tbEngineer, _tbProjectName, _tbProjectCode;
        private RadioButton _rbRevit, _rbManual;
        private CheckBox _cbInfil, _cbOrient, _cbAngular;
        private CheckBox _cbFancoil, _cbConvector, _cbRadiator, _cbAHU;

        public SettingsWindow(HvacSettings current)
        {
            _original = current;
            Result    = current;
            BuildUI();
            LoadValues(current);
            Title  = "Настройки HvacCalc";
            Width  = 520;
            Height = 680;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void BuildUI()
        {
            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            var root   = new StackPanel { Margin = new Thickness(16) };
            scroll.Content = root;
            Content = scroll;

            // Проект
            AddHeader(root, "Проект");
            _tbProjectName  = AddRow(root, "Наименование объекта:");
            _tbProjectCode  = AddRow(root, "Шифр:");
            _tbEngineer     = AddRow(root, "Инженер:");

            // Климат
            AddHeader(root, "Климат (СП 131)");
            _tbCity = AddRow(root, "Город:");
            _tbTExt = AddRow(root, "t_нар расч. (парам. Б), °С:");

            // Внутренний микроклимат
            AddHeader(root, "Внутренний микроклимат");
            _tbTInt   = AddRow(root, "t_вн по умолчанию, °С:");
            _tbTParam = AddRow(root, "Имя параметра помещения t_вн:");

            // Источник данных об ограждениях
            AddHeader(root, "Ограждающие конструкции");
            var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0,4,0,4) };
            _rbRevit  = new RadioButton { Content = "Из параметров типов Revit", Margin = new Thickness(0,0,16,0) };
            _rbManual = new RadioButton { Content = "Ручной ввод" };
            panel.Children.Add(_rbRevit);
            panel.Children.Add(_rbManual);
            root.Children.Add(panel);

            _tbRParam = AddRow(root, "Имя параметра типа (R_ред):");
            _tbRWall  = AddRow(root, "R_ред стены (ручной), м²·°С/Вт:");
            _tbRWin   = AddRow(root, "R_ред окна/двери:");
            _tbRRoof  = AddRow(root, "R_ред крыши:");
            _tbRFloor = AddRow(root, "R_ред пола:");

            // Надбавки
            AddHeader(root, "Надбавки (СП 60, прил. Б)");
            _cbOrient  = AddCheck(root, "Надбавка по ориентации");
            _cbAngular = AddCheck(root, "Надбавка угловое помещение (+5%)");
            _cbInfil   = AddCheck(root, "Учитывать инфильтрацию");
            _tbOverpower = AddRow(root, "Запас мощности оборудования (доля):");

            // Типы оборудования
            AddHeader(root, "Оборудование для подбора");
            _cbFancoil   = AddCheck(root, "Фанкойлы");
            _cbConvector = AddCheck(root, "Конвекторы водяные");
            _cbRadiator  = AddCheck(root, "Радиаторы");
            _cbAHU       = AddCheck(root, "Приточные установки (AHU)");

            // Кнопки
            var btnPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 16, 0, 0)
            };
            var btnOk     = new Button { Content = "OK",     Width = 80, Margin = new Thickness(0,0,8,0), IsDefault = true };
            var btnCancel = new Button { Content = "Отмена", Width = 80, IsCancel = true };
            btnOk.Click     += (_, __) => { SaveValues(); DialogResult = true; };
            btnCancel.Click += (_, __) => { DialogResult = false; };
            btnPanel.Children.Add(btnOk);
            btnPanel.Children.Add(btnCancel);
            root.Children.Add(btnPanel);
        }

        private void LoadValues(HvacSettings s)
        {
            _tbProjectName.Text = s.ProjectName;
            _tbProjectCode.Text = s.ProjectCode;
            _tbEngineer.Text    = s.Engineer;
            _tbCity.Text        = s.City;
            _tbTExt.Text        = s.TExteriorDesign.ToString("F1");
            _tbTInt.Text        = s.TInteriorDefault.ToString("F1");
            _tbTParam.Text      = s.TInteriorParamName;
            _rbRevit.IsChecked  = s.EnvelopeSource == EnvelopeDataSource.RevitWallTypes;
            _rbManual.IsChecked = s.EnvelopeSource == EnvelopeDataSource.ManualInput;
            _tbRParam.Text      = s.RReducedParamName;
            _tbRWall.Text       = s.RWallDefault.ToString("F2");
            _tbRWin.Text        = s.RWindowDefault.ToString("F2");
            _tbRRoof.Text       = s.RRoofDefault.ToString("F2");
            _tbRFloor.Text      = s.RFloorDefault.ToString("F2");
            _cbOrient.IsChecked  = s.UseOrientationBonus;
            _cbAngular.IsChecked = s.UseAngularBonus;
            _cbInfil.IsChecked   = s.CalcInfiltration;
            _tbOverpower.Text    = s.OverpowerCoeff.ToString("F2");
            _cbFancoil.IsChecked   = s.SelectFancoils;
            _cbConvector.IsChecked = s.SelectConvectors;
            _cbRadiator.IsChecked  = s.SelectRadiators;
            _cbAHU.IsChecked       = s.SelectAHU;
        }

        private void SaveValues()
        {
            Result = new HvacSettings
            {
                ProjectName        = _tbProjectName.Text,
                ProjectCode        = _tbProjectCode.Text,
                Engineer           = _tbEngineer.Text,
                City               = _tbCity.Text,
                TExteriorDesign    = ParseDouble(_tbTExt.Text,   _original.TExteriorDesign),
                TInteriorDefault   = ParseDouble(_tbTInt.Text,   _original.TInteriorDefault),
                TInteriorParamName = _tbTParam.Text,
                EnvelopeSource     = _rbRevit.IsChecked == true
                    ? EnvelopeDataSource.RevitWallTypes
                    : EnvelopeDataSource.ManualInput,
                RReducedParamName  = _tbRParam.Text,
                RWallDefault       = ParseDouble(_tbRWall.Text,  _original.RWallDefault),
                RWindowDefault     = ParseDouble(_tbRWin.Text,   _original.RWindowDefault),
                RRoofDefault       = ParseDouble(_tbRRoof.Text,  _original.RRoofDefault),
                RFloorDefault      = ParseDouble(_tbRFloor.Text, _original.RFloorDefault),
                UseOrientationBonus= _cbOrient.IsChecked  == true,
                UseAngularBonus    = _cbAngular.IsChecked == true,
                CalcInfiltration   = _cbInfil.IsChecked   == true,
                OverpowerCoeff     = ParseDouble(_tbOverpower.Text, _original.OverpowerCoeff),
                SelectFancoils     = _cbFancoil.IsChecked   == true,
                SelectConvectors   = _cbConvector.IsChecked == true,
                SelectRadiators    = _cbRadiator.IsChecked  == true,
                SelectAHU          = _cbAHU.IsChecked       == true,
                // Сохраняем остальные поля без изменений
                ResultParamHeatLoad = _original.ResultParamHeatLoad,
                ResultParamTemp     = _original.ResultParamTemp,
                ReportOutputPath    = _original.ReportOutputPath,
                InfiltrationCoeff   = _original.InfiltrationCoeff,
            };
        }

        // ── Хелперы ────────────────────────────────────────────────
        private static void AddHeader(Panel p, string text)
        {
            p.Children.Add(new TextBlock
            {
                Text = text, FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 14, 0, 4)
            });
        }

        private static TextBox AddRow(Panel p, string label)
        {
            var sp  = new StackPanel { Margin = new Thickness(0, 2, 0, 2) };
            var lbl = new TextBlock  { Text = label, Margin = new Thickness(0, 0, 0, 1) };
            var tb  = new TextBox    { Height = 24, Padding = new Thickness(4, 2, 4, 2) };
            sp.Children.Add(lbl);
            sp.Children.Add(tb);
            p.Children.Add(sp);
            return tb;
        }

        private static CheckBox AddCheck(Panel p, string label)
        {
            var cb = new CheckBox { Content = label, Margin = new Thickness(0, 3, 0, 3) };
            p.Children.Add(cb);
            return cb;
        }

        private static double ParseDouble(string s, double fallback)
        {
            if (double.TryParse(s.Replace(',', '.'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out double v))
                return v;
            return fallback;
        }
    }
}
