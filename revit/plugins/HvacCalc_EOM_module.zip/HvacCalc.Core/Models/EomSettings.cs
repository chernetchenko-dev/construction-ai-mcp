namespace HvacCalc.Core.Models
{
    /// <summary>
    /// Настройки расчёта ТРН ЭОМ
    /// </summary>
    public class EomSettings
    {
        // === Тип здания (для Ксп освещения, табл. 7.6) ===
        public BuildingType BuildingType { get; set; } = BuildingType.OfficeAdmin;

        // === Параметр семейства для ручной категории ===
        // Имя параметра типа/экземпляра, где указана категория нагрузки текстом
        public string CategoryParamName { get; set; } = "ЭОМ_КатегорияНагрузки";

        // === Параметр мощности ===
        public string PowerParamName    { get; set; } = "ADSK_Мощность";

        // === Fallback cosφ по категориям ===
        public double CosPhiLighting    { get; set; } = 0.92;   // ЛЛ, СД — табл. 7.12
        public double CosPhiSockets     { get; set; } = 0.85;
        public double CosPhiLifts       { get; set; } = 0.65;
        public double CosPhiPumps       { get; set; } = 0.80;
        public double CosPhiTech        { get; set; } = 0.85;
        public double CosPhiForce       { get; set; } = 0.80;

        // === Ручной коэффициент несовпадения 7.11 (0 = авто) ===
        public double KcoincidenceOverride { get; set; } = 0;

        // === Уровень учёта розеток (групповые/питающие/ввод) ===
        // 0=групповые (1.0), 1=питающие (0.2/0.4), 2=ввод (0.1/0.2)
        public int SocketKspLevel       { get; set; } = 1;

        // === Напряжение для расчёта тока ===
        public double VoltageKv         { get; set; } = 0.38;

        // === Исключить противопожарные из расчётной нагрузки ===
        public bool ExcludeEmergency    { get; set; } = true;

        // === Реквизиты проекта ===
        public string ProjectName       { get; set; } = "";
        public string ProjectCode       { get; set; } = "";
        public string Engineer          { get; set; } = "";
        public string ReportOutputPath  { get; set; } = "";
    }
}
