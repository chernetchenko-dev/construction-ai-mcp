namespace HvacCalc.Core.Models
{
    /// <summary>
    /// Категория нагрузки по СП 256.1325800.2016
    /// </summary>
    public enum LoadCategory
    {
        Lighting,       // Освещение (табл. 7.6)
        Sockets,        // Розетки (табл. 7.7)
        ForceLifts,     // Лифты (табл. 7.4)
        ForcePumps,     // Насосы, вентиляторы (табл. 7.5)
        ForceTech,      // Технологическое оборудование (табл. 7.8)
        ForceGeneral,   // Прочая сила
        Emergency,      // Противопожарные (Ксп = 1)
        Unknown
    }

    /// <summary>
    /// Тип здания для выбора Ксп освещения по табл. 7.6 СП 256
    /// </summary>
    public enum BuildingType
    {
        OfficeAdmin,        // Организации управления, проектные, НИИ
        Hotel,              // Гостиницы, санатории
        Restaurant,         // Предприятия общественного питания, детские сады
        School,             // Школы, учебные заведения
        Trade,              // Предприятия торговли
        ConferenceHall,     // Актовые залы, конференц-залы, спортзалы
        Club,               // Клубы, дома культуры
        Cinema,             // Кинотеатры
    }

    /// <summary>
    /// Единица нагрузки — один элемент из модели Revit
    /// </summary>
    public class EomLoadItem
    {
        public int    RevitId      { get; set; }
        public string FamilyName   { get; set; }
        public string TypeName     { get; set; }
        public string RoomNumber   { get; set; }
        public string RoomName     { get; set; }
        public string Level        { get; set; }
        public LoadCategory Category { get; set; }
        public double PowerW       { get; set; }   // ADSK_Мощность, Вт
        public double CosPhi       { get; set; }   // cosφ
        public string CategorySource { get; set; } // "OST" или "Param"
    }

    /// <summary>
    /// Группа нагрузок одной категории в ТРН
    /// </summary>
    public class TrnGroup
    {
        public LoadCategory Category   { get; set; }
        public string       Name       { get; set; }   // «Освещение», «Розетки» и т.д.
        public int          Count      { get; set; }   // кол-во ед.
        public double       Pinstalled { get; set; }   // Руст, кВт
        public double       Ksp        { get; set; }   // коэф. спроса
        public double       Pcalc      { get; set; }   // Рр = Руст × Ксп, кВт
        public double       CosPhi     { get; set; }   // cosφ средний
        public double       TgPhi      { get; set; }   // tgφ
        public double       Qcalc      { get; set; }   // Qр = Рр × tgφ, квар
        public double       Scalc      { get; set; }   // Sр = √(Рр²+Qр²), кВА
        public double       Icalc      { get; set; }   // Iр при 0.38 кВ, А
    }

    /// <summary>
    /// Итоговая ТРН по зданию
    /// </summary>
    public class TrnResult
    {
        public string ProjectName  { get; set; }
        public string ProjectCode  { get; set; }
        public string Engineer     { get; set; }
        public string Date         { get; set; }
        public BuildingType BuildingType { get; set; }

        public System.Collections.Generic.List<TrnGroup> Groups { get; set; }
            = new System.Collections.Generic.List<TrnGroup>();

        // Итог по вводу (с коэф. несовпадения 7.11)
        public double Kcoincidence { get; set; }   // K по табл. 7.11
        public double PtotalInstalled { get; set; }
        public double PtotalCalc   { get; set; }   // кВт
        public double QtotalCalc   { get; set; }   // квар
        public double StotalCalc   { get; set; }   // кВА
        public double ItotalCalc   { get; set; }   // А при 0.38 кВ

        // Все элементы (для детального листа Excel)
        public System.Collections.Generic.List<EomLoadItem> Items { get; set; }
            = new System.Collections.Generic.List<EomLoadItem>();
    }
}
