using System;
using System.Collections.Generic;
using System.Linq;
using HvacCalc.Core.Models;

namespace HvacCalc.Core.Services
{
    /// <summary>
    /// Расчёт ТРН по СП 256.1325800.2016.
    /// Реализованы таблицы: 7.4, 7.5, 7.6, 7.7, 7.11, 7.12.
    /// Не зависит от Revit API.
    /// </summary>
    public class TrnCalculator
    {
        private readonly EomSettings _s;

        public TrnCalculator(EomSettings settings)
        {
            _s = settings ?? throw new ArgumentNullException(nameof(settings));
        }

        // ──────────────────────────────────────────────────────────────
        // ТОЧКА ВХОДА
        // ──────────────────────────────────────────────────────────────
        public TrnResult Calculate(IEnumerable<EomLoadItem> items, string projectName = "",
            string projectCode = "", string engineer = "")
        {
            var itemList = items.ToList();
            var result = new TrnResult
            {
                ProjectName  = projectName,
                ProjectCode  = projectCode,
                Engineer     = engineer,
                Date         = DateTime.Now.ToString("dd.MM.yyyy"),
                BuildingType = _s.BuildingType,
                Items        = itemList,
            };

            // Сгруппировать по категории
            var byCategory = itemList
                .GroupBy(i => i.Category)
                .ToList();

            foreach (var grp in byCategory)
            {
                var g = BuildGroup(grp.Key, grp.ToList());
                if (g != null) result.Groups.Add(g);
            }

            // Итог
            result.PtotalInstalled = result.Groups.Sum(g => g.Pinstalled);
            double ptotCalcRaw     = result.Groups.Sum(g => g.Pcalc);
            double qtotCalcRaw     = result.Groups.Sum(g => g.Qcalc);

            // Коэффициент несовпадения максимумов (табл. 7.11)
            result.Kcoincidence = _s.KcoincidenceOverride > 0
                ? _s.KcoincidenceOverride
                : GetKcoincidence(result.Groups);

            result.PtotalCalc = Math.Round(ptotCalcRaw * result.Kcoincidence, 2);
            result.QtotalCalc = Math.Round(qtotCalcRaw * result.Kcoincidence, 2);
            result.StotalCalc = Math.Round(
                Math.Sqrt(result.PtotalCalc * result.PtotalCalc +
                          result.QtotalCalc * result.QtotalCalc), 2);
            result.ItotalCalc = Math.Round(
                result.StotalCalc / (Math.Sqrt(3) * _s.VoltageKv), 1);

            return result;
        }

        // ──────────────────────────────────────────────────────────────
        // ГРУППА ПО КАТЕГОРИИ
        // ──────────────────────────────────────────────────────────────
        private TrnGroup BuildGroup(LoadCategory cat, List<EomLoadItem> items)
        {
            if (cat == LoadCategory.Unknown) return null;
            if (_s.ExcludeEmergency && cat == LoadCategory.Emergency) return null;

            double pInst = items.Sum(i => i.PowerW) / 1000.0; // Вт → кВт
            int    count = items.Count;

            double ksp   = GetKsp(cat, pInst, count);
            double cosPhi = GetCosPhi(cat, items);
            double tgPhi  = cosPhi > 0 ? Math.Sqrt(1 - cosPhi * cosPhi) / cosPhi : 0;

            double pCalc = Math.Round(pInst * ksp, 3);
            double qCalc = Math.Round(pCalc * tgPhi, 3);
            double sCalc = Math.Round(Math.Sqrt(pCalc * pCalc + qCalc * qCalc), 3);
            double iCalc = Math.Round(sCalc / (Math.Sqrt(3) * _s.VoltageKv), 1);

            return new TrnGroup
            {
                Category   = cat,
                Name       = CategoryName(cat),
                Count      = count,
                Pinstalled = Math.Round(pInst, 3),
                Ksp        = ksp,
                Pcalc      = pCalc,
                CosPhi     = cosPhi,
                TgPhi      = Math.Round(tgPhi, 3),
                Qcalc      = qCalc,
                Scalc      = sCalc,
                Icalc      = iCalc,
            };
        }

        // ──────────────────────────────────────────────────────────────
        // КСП ПО КАТЕГОРИЯМ
        // ──────────────────────────────────────────────────────────────
        private double GetKsp(LoadCategory cat, double pInstKw, int count)
        {
            switch (cat)
            {
                case LoadCategory.Lighting:
                    return KspLighting(_s.BuildingType, pInstKw);
                case LoadCategory.Sockets:
                    return KspSockets(_s.BuildingType, _s.SocketKspLevel);
                case LoadCategory.ForceLifts:
                    return KspLifts(count);
                case LoadCategory.ForcePumps:
                    return KspSantech(count);
                case LoadCategory.ForceTech:
                    return KspTech(count);
                case LoadCategory.Emergency:
                    return 1.0;
                default:
                    return count <= 3 ? 0.8 : 0.6;
            }
        }

        // ── Табл. 7.6: Ксп освещения ──────────────────────────────────
        // Ключ: (тип здания, Руст кВт) → Ксп
        private static double KspLighting(BuildingType bt, double pKw)
        {
            // Интерполяция между опорными точками
            double[] pw = { 0, 5, 10, 15, 25, 50, 100, 200, 400, 501 };

            double[] ks;
            switch (bt)
            {
                case BuildingType.Hotel:
                    ks = new[] { 1.0, 1.0, 0.8, 0.7, 0.6, 0.5, 0.4, 0.35, 0.3, 0.3 };
                    break;
                case BuildingType.Restaurant:
                    ks = new[] { 1.0, 1.0, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6, 0.5 };
                    break;
                case BuildingType.ConferenceHall:
                    ks = new[] { 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0 };
                    break;
                case BuildingType.Club:
                    ks = new[] { 1.0, 1.0, 0.9, 0.8, 0.75, 0.7, 0.65, 0.55, 0.55, 0.55 };
                    break;
                case BuildingType.Cinema:
                    ks = new[] { 1.0, 1.0, 0.9, 0.8, 0.7, 0.65, 0.6, 0.5, 0.5, 0.5 };
                    break;
                case BuildingType.School:
                case BuildingType.Trade:
                    ks = new[] { 1.0, 1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6 };
                    break;
                default: // OfficeAdmin + НИИ
                    ks = new[] { 1.0, 1.0, 1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65 };
                    break;
            }
            return Interpolate(pw, ks, pKw);
        }

        // ── Табл. 7.7: Ксп розеток ────────────────────────────────────
        private static double KspSockets(BuildingType bt, int level)
        {
            // level 0=групповые, 1=питающие, 2=ввод
            bool isHotel = bt == BuildingType.Hotel || bt == BuildingType.Restaurant;
            switch (level)
            {
                case 0: return 1.0;
                case 1: return isHotel ? 0.4 : 0.2;
                case 2: return isHotel ? 0.2 : 0.1;
                default: return 0.2;
            }
        }

        // ── Табл. 7.4: Ксп лифтов ────────────────────────────────────
        // Упрощённо: здание > 12 этажей определяется через настройки
        private static double KspLifts(int count)
        {
            // Строки таблицы 7.4: число установок → (До12, 12 и св.)
            // Берём "До 12" как базовый
            if (count <= 2)  return 0.8;
            if (count <= 4)  return 0.7;
            if (count <= 6)  return 0.65;
            if (count <= 10) return 0.5;
            if (count <= 20) return 0.4;
            return 0.35;
        }

        // ── Табл. 7.5: Ксп санех/насосов ──────────────────────────────
        private static double KspSantech(int count)
        {
            // Позиция 1 (100-85%): строка 1 таблицы 7.5
            if (count <= 2)  return 1.0;
            if (count <= 3)  return 0.9;
            if (count <= 5)  return 0.8;
            if (count <= 8)  return 0.75;
            if (count <= 10) return 0.7;
            if (count <= 15) return 0.65;
            if (count <= 20) return 0.65;
            if (count <= 30) return 0.6;
            if (count <= 50) return 0.55;
            return 0.5;
        }

        // ── Табл. 7.8: Ксп технологического оборудования ──────────────
        private static double KspTech(int count)
        {
            // Строка 15 (парикмахерские, ателье, торговля, медкабинеты)
            return count <= 3 ? 0.6 : 0.3;
        }

        // ──────────────────────────────────────────────────────────────
        // COSΦ
        // ──────────────────────────────────────────────────────────────
        private double GetCosPhi(LoadCategory cat, List<EomLoadItem> items)
        {
            // Средневзвешенное по мощности, если у элементов задан cosφ
            var withCos = items.Where(i => i.CosPhi > 0 && i.CosPhi <= 1).ToList();
            if (withCos.Count > 0)
            {
                double sumW   = withCos.Sum(i => i.PowerW);
                double sumWcp = withCos.Sum(i => i.PowerW * i.CosPhi);
                if (sumW > 0) return Math.Round(sumWcp / sumW, 3);
            }

            // Fallback по табл. 7.12
            switch (cat)
            {
                case LoadCategory.Lighting:    return _s.CosPhiLighting;
                case LoadCategory.Sockets:     return _s.CosPhiSockets;
                case LoadCategory.ForceLifts:  return _s.CosPhiLifts;
                case LoadCategory.ForcePumps:  return _s.CosPhiPumps;
                case LoadCategory.ForceTech:   return _s.CosPhiTech;
                default:                       return _s.CosPhiForce;
            }
        }

        // ──────────────────────────────────────────────────────────────
        // КОЭФ. НЕСОВПАДЕНИЯ МАКСИМУМОВ (табл. 7.11)
        // ──────────────────────────────────────────────────────────────
        private double GetKcoincidence(List<TrnGroup> groups)
        {
            double pLight = groups.Where(g => g.Category == LoadCategory.Lighting)
                                  .Sum(g => g.Pcalc);
            double pForce = groups.Where(g => g.Category != LoadCategory.Lighting &&
                                              g.Category != LoadCategory.Sockets)
                                  .Sum(g => g.Pcalc);

            if (pForce < 0.001) return 1.0;  // нет силы — совпадение полное

            double ratio = pLight / pForce * 100; // %

            // Табл. 7.11 строка офис/управление (самая распространённая)
            if (ratio < 20 || ratio > 250) return 1.0;
            if (ratio <= 75)  return _s.BuildingType == BuildingType.Hotel ? 0.9 : 0.95;
            if (ratio <= 140) return _s.BuildingType == BuildingType.Hotel ? 0.85 : 0.9;
            return _s.BuildingType == BuildingType.Hotel ? 0.9 : 0.95;
        }

        // ──────────────────────────────────────────────────────────────
        // ВСПОМОГАТЕЛЬНЫЕ
        // ──────────────────────────────────────────────────────────────
        private static double Interpolate(double[] x, double[] y, double xi)
        {
            if (xi <= x[0])  return y[0];
            if (xi >= x[x.Length - 1]) return y[y.Length - 1];
            for (int i = 0; i < x.Length - 1; i++)
            {
                if (xi >= x[i] && xi <= x[i + 1])
                {
                    double t = (xi - x[i]) / (x[i + 1] - x[i]);
                    return y[i] + t * (y[i + 1] - y[i]);
                }
            }
            return y[y.Length - 1];
        }

        public static string CategoryName(LoadCategory cat)
        {
            switch (cat)
            {
                case LoadCategory.Lighting:    return "Освещение";
                case LoadCategory.Sockets:     return "Розетки";
                case LoadCategory.ForceLifts:  return "Лифты";
                case LoadCategory.ForcePumps:  return "Насосы, вентиляторы";
                case LoadCategory.ForceTech:   return "Технологическое оборудование";
                case LoadCategory.ForceGeneral:return "Прочая силовая нагрузка";
                case LoadCategory.Emergency:   return "Противопожарные устройства";
                default:                       return "Неклассифицировано";
            }
        }
    }
}
