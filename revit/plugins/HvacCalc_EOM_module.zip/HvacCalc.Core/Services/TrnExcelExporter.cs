using System;
using System.Collections.Generic;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using HvacCalc.Core.Models;
using System.Drawing;

namespace HvacCalc.Core.Services
{
    /// <summary>
    /// Экспорт ТРН в Excel (.xlsx) через EPPlus.
    /// Лист 1 — сводная ТРН.
    /// Лист 2 — детализация по элементам.
    /// </summary>
    public class TrnExcelExporter
    {
        // ── EPPlus: лицензия некоммерческая ───────────────────────────
        static TrnExcelExporter()
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        public string Export(TrnResult result, string outputDir)
        {
            string fileName = $"TRN_EOM_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
            string fullPath = Path.Combine(outputDir, fileName);

            using (var pkg = new ExcelPackage())
            {
                BuildSummarySheet(pkg, result);
                BuildDetailSheet(pkg, result);
                pkg.SaveAs(new FileInfo(fullPath));
            }
            return fullPath;
        }

        // ══════════════════════════════════════════════════════════════
        // ЛИСТ 1: СВОДНАЯ ТРН
        // ══════════════════════════════════════════════════════════════
        private void BuildSummarySheet(ExcelPackage pkg, TrnResult r)
        {
            var ws = pkg.Workbook.Worksheets.Add("ТРН (сводная)");

            // Ширина столбцов
            ws.Column(1).Width = 5;
            ws.Column(2).Width = 36;
            ws.Column(3).Width = 8;
            ws.Column(4).Width = 12;
            ws.Column(5).Width = 10;
            ws.Column(6).Width = 12;
            ws.Column(7).Width = 8;
            ws.Column(8).Width = 8;
            ws.Column(9).Width = 12;
            ws.Column(10).Width = 12;
            ws.Column(11).Width = 12;

            int row = 1;

            // Шапка
            MergeBold(ws, row, 1, row, 11,
                "ТАБЛИЦА РАСЧЁТНЫХ НАГРУЗОК (ТРН)");
            ws.Cells[row, 1].Style.Font.Size = 13;
            row++;

            MergeBold(ws, row, 1, row, 11,
                "Раздел: Электроснабжение (ЭОМ)");
            row++;
            row++;

            // Реквизиты
            AddMeta(ws, ref row, "Объект:", r.ProjectName);
            AddMeta(ws, ref row, "Шифр:", r.ProjectCode);
            AddMeta(ws, ref row, "Инженер:", r.Engineer);
            AddMeta(ws, ref row, "Дата:", r.Date);
            AddMeta(ws, ref row, "Тип здания:", BuildingTypeName(r.BuildingType));
            AddMeta(ws, ref row, "Нормативная база:",
                "СП 256.1325800.2016, раздел 7");
            row++;

            // Заголовок таблицы
            var hdr = new[]
            {
                "№", "Наименование нагрузки", "Кол.", "Руст, кВт",
                "Ксп", "Рр, кВт", "cosφ", "tgφ", "Qр, квар",
                "Sр, кВА", "Iр, А"
            };
            for (int c = 0; c < hdr.Length; c++)
            {
                var cell = ws.Cells[row, c + 1];
                cell.Value = hdr[c];
                cell.Style.Font.Bold = true;
                cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                cell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(68, 114, 196));
                cell.Style.Font.Color.SetColor(Color.White);
                cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                cell.Style.VerticalAlignment   = ExcelVerticalAlignment.Center;
                cell.Style.WrapText = true;
            }
            ws.Rows[row].Height = 36;
            row++;

            // Строки групп
            int n = 1;
            foreach (var g in r.Groups)
            {
                bool isEmerg = g.Category == LoadCategory.Emergency;
                var rowColor = isEmerg ? Color.FromArgb(255, 230, 230)
                             : (n % 2 == 0 ? Color.FromArgb(242, 242, 242)
                                           : Color.White);

                ws.Cells[row, 1].Value  = n++;
                ws.Cells[row, 2].Value  = g.Name;
                ws.Cells[row, 3].Value  = g.Count;
                ws.Cells[row, 4].Value  = g.Pinstalled;
                ws.Cells[row, 5].Value  = g.Ksp;
                ws.Cells[row, 6].Value  = g.Pcalc;
                ws.Cells[row, 7].Value  = g.CosPhi;
                ws.Cells[row, 8].Value  = g.TgPhi;
                ws.Cells[row, 9].Value  = g.Qcalc;
                ws.Cells[row, 10].Value = g.Scalc;
                ws.Cells[row, 11].Value = g.Icalc;

                FormatDataRow(ws, row, 1, 11, rowColor);
                ApplyNumFmt(ws, row, 4, "0.000");
                ApplyNumFmt(ws, row, 5, "0.00");
                ApplyNumFmt(ws, row, 6, "0.000");
                ApplyNumFmt(ws, row, 7, "0.000");
                ApplyNumFmt(ws, row, 8, "0.000");
                ApplyNumFmt(ws, row, 9, "0.000");
                ApplyNumFmt(ws, row, 10, "0.00");
                ApplyNumFmt(ws, row, 11, "0.0");
                row++;
            }

            // Итоговая строка (до несовпадения)
            ws.Cells[row, 2].Value = "Итого (установленная / расчётная без K)";
            ws.Cells[row, 4].Value = r.PtotalInstalled;
            ws.Cells[row, 6].Value = r.Groups.Sum(g => g.Pcalc);
            ws.Cells[row, 9].Value = r.Groups.Sum(g => g.Qcalc);
            FormatTotalRow(ws, row, 1, 11, Color.FromArgb(180, 198, 231));
            row++;

            // Строка несовпадения
            ws.Cells[row, 2].Value = $"Коэффициент несовпадения максимумов K (табл. 7.11)";
            ws.Cells[row, 5].Value = r.Kcoincidence;
            FormatDataRow(ws, row, 1, 11, Color.FromArgb(255, 243, 204));
            ApplyNumFmt(ws, row, 5, "0.00");
            row++;

            // Итог по вводу
            ws.Cells[row, 2].Value  = "ИТОГО НА ВВОДЕ";
            ws.Cells[row, 4].Value  = r.PtotalInstalled;
            ws.Cells[row, 6].Value  = r.PtotalCalc;
            ws.Cells[row, 9].Value  = r.QtotalCalc;
            ws.Cells[row, 10].Value = r.StotalCalc;
            ws.Cells[row, 11].Value = r.ItotalCalc;
            FormatTotalRow(ws, row, 1, 11, Color.FromArgb(68, 114, 196));
            // Белый жирный текст
            for (int c = 1; c <= 11; c++)
            {
                ws.Cells[row, c].Style.Font.Color.SetColor(Color.White);
                ws.Cells[row, c].Style.Font.Bold = true;
            }
            ApplyNumFmt(ws, row, 4, "0.000");
            ApplyNumFmt(ws, row, 6, "0.000");
            ApplyNumFmt(ws, row, 9, "0.000");
            ApplyNumFmt(ws, row, 10, "0.00");
            ApplyNumFmt(ws, row, 11, "0.0");
            ws.Rows[row].Height = 22;
            row += 2;

            // Примечания
            ws.Cells[row, 1].Value = "Примечания:";
            ws.Cells[row, 1].Style.Font.Bold = true;
            ws.MergedCells[row, 1, row, 11] = true;
            row++;

            var notes = new[]
            {
                "1. Ксп освещения принят по табл. 7.6 СП 256.1325800.2016 в зависимости от типа здания и Руст.",
                "2. Ксп розеток принят по табл. 7.7 СП 256.1325800.2016 (уровень питающих сетей).",
                "3. Ксп лифтов принят по табл. 7.4, насосов/вентиляторов — по табл. 7.5.",
                "4. cosφ принят по табл. 7.12 СП 256.1325800.2016.",
                "5. Коэффициент несовпадения максимумов принят по табл. 7.11.",
                "6. Токи рассчитаны при U = 0,38 кВ (трёхфазная сеть).",
            };
            foreach (var note in notes)
            {
                ws.Cells[row, 1].Value = note;
                ws.MergedCells[row, 1, row, 11] = true;
                ws.Cells[row, 1].Style.Font.Italic = true;
                ws.Cells[row, 1].Style.Font.Size = 9;
                row++;
            }

            // Внешняя рамка таблицы
            var tableRange = ws.Cells[10, 1, row - 7, 11];
            tableRange.Style.Border.BorderAround(ExcelBorderStyle.Medium);

            ws.View.FreezePanes(10, 1);
        }

        // ══════════════════════════════════════════════════════════════
        // ЛИСТ 2: ДЕТАЛИЗАЦИЯ
        // ══════════════════════════════════════════════════════════════
        private void BuildDetailSheet(ExcelPackage pkg, TrnResult r)
        {
            var ws = pkg.Workbook.Worksheets.Add("Детализация");

            ws.Column(1).Width = 10;
            ws.Column(2).Width = 30;
            ws.Column(3).Width = 30;
            ws.Column(4).Width = 18;
            ws.Column(5).Width = 18;
            ws.Column(6).Width = 12;
            ws.Column(7).Width = 14;
            ws.Column(8).Width = 18;

            int row = 1;
            var hdr = new[] { "Revit ID", "Семейство", "Тип",
                               "Помещение №", "Помещение",
                               "Руст, Вт", "Категория", "Источник кат." };
            for (int c = 0; c < hdr.Length; c++)
            {
                ws.Cells[row, c + 1].Value = hdr[c];
                ws.Cells[row, c + 1].Style.Font.Bold = true;
                ws.Cells[row, c + 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                ws.Cells[row, c + 1].Style.Fill.BackgroundColor
                    .SetColor(Color.FromArgb(68, 114, 196));
                ws.Cells[row, c + 1].Style.Font.Color.SetColor(Color.White);
                ws.Cells[row, c + 1].Style.HorizontalAlignment =
                    ExcelHorizontalAlignment.Center;
            }
            ws.Rows[row].Height = 24;
            row++;

            int idx = 0;
            foreach (var item in r.Items)
            {
                var bg = idx++ % 2 == 0 ? Color.White
                                        : Color.FromArgb(242, 242, 242);
                ws.Cells[row, 1].Value = item.RevitId;
                ws.Cells[row, 2].Value = item.FamilyName;
                ws.Cells[row, 3].Value = item.TypeName;
                ws.Cells[row, 4].Value = item.RoomNumber;
                ws.Cells[row, 5].Value = item.RoomName;
                ws.Cells[row, 6].Value = item.PowerW;
                ws.Cells[row, 7].Value = TrnCalculator.CategoryName(item.Category);
                ws.Cells[row, 8].Value = item.CategorySource;
                FormatDataRow(ws, row, 1, 8, bg);
                row++;
            }

            ws.AutoFilter.Address = ws.Cells[1, 1, row - 1, 8];
            ws.View.FreezePanes(2, 1);
        }

        // ──────────────────────────────────────────────────────────────
        // Стили
        // ──────────────────────────────────────────────────────────────
        private static void MergeBold(ExcelWorksheet ws,
            int r1, int c1, int r2, int c2, string text)
        {
            ws.MergedCells[r1, c1, r2, c2] = true;
            ws.Cells[r1, c1].Value = text;
            ws.Cells[r1, c1].Style.Font.Bold = true;
            ws.Cells[r1, c1].Style.HorizontalAlignment =
                ExcelHorizontalAlignment.Center;
        }

        private static void AddMeta(ExcelWorksheet ws, ref int row,
            string label, string value)
        {
            ws.Cells[row, 1].Value = label;
            ws.Cells[row, 1].Style.Font.Bold = true;
            ws.MergedCells[row, 2, row, 11] = true;
            ws.Cells[row, 2].Value = value;
            row++;
        }

        private static void FormatDataRow(ExcelWorksheet ws,
            int row, int c1, int c2, Color bg)
        {
            for (int c = c1; c <= c2; c++)
            {
                var cell = ws.Cells[row, c];
                cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                cell.Style.Fill.BackgroundColor.SetColor(bg);
                cell.Style.Border.Top.Style    = ExcelBorderStyle.Thin;
                cell.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                cell.Style.Border.Left.Style   = ExcelBorderStyle.Thin;
                cell.Style.Border.Right.Style  = ExcelBorderStyle.Thin;
                cell.Style.HorizontalAlignment =
                    c == 2 ? ExcelHorizontalAlignment.Left
                           : ExcelHorizontalAlignment.Center;
            }
        }

        private static void FormatTotalRow(ExcelWorksheet ws,
            int row, int c1, int c2, Color bg)
        {
            FormatDataRow(ws, row, c1, c2, bg);
            ws.Cells[row, c1, row, c2].Style.Font.Bold = true;
        }

        private static void ApplyNumFmt(ExcelWorksheet ws, int row, int col, string fmt)
        {
            var v = ws.Cells[row, col].Value;
            if (v != null) ws.Cells[row, col].Style.Numberformat.Format = fmt;
        }

        private static double Sum(IEnumerable<TrnGroup> groups,
            Func<TrnGroup, double> sel) => groups.Aggregate(0.0, (a, g) => a + sel(g));

        private static string BuildingTypeName(BuildingType bt)
        {
            switch (bt)
            {
                case BuildingType.OfficeAdmin:    return "Административное / офисное";
                case BuildingType.Hotel:          return "Гостиница / санаторий";
                case BuildingType.Restaurant:     return "Общественное питание / детский сад";
                case BuildingType.School:         return "Школа / учебное заведение";
                case BuildingType.Trade:          return "Торговля";
                case BuildingType.ConferenceHall: return "Актовый / конференц-зал";
                case BuildingType.Club:           return "Клуб / дом культуры";
                case BuildingType.Cinema:         return "Кинотеатр";
                default:                          return bt.ToString();
            }
        }
    }
}
