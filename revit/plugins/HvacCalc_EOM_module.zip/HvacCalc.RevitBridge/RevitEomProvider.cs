using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using HvacCalc.Core.Models;

namespace HvacCalc.RevitBridge
{
    /// <summary>
    /// Читает нагрузки ЭОМ из модели Revit.
    /// Категория определяется двумя способами:
    ///   1. По OST-категории семейства (приоритет)
    ///   2. По параметру семейства EomSettings.CategoryParamName
    /// ADSK_Мощность читается как установленная мощность единицы, Вт.
    /// </summary>
    public class RevitEomProvider
    {
        private readonly Document    _doc;
        private readonly EomSettings _s;

        private const double Ft2 = 0.3048 * 0.3048;

        // Маппинг OST-категории → LoadCategory
        private static readonly Dictionary<BuiltInCategory, LoadCategory> OstMap
            = new Dictionary<BuiltInCategory, LoadCategory>
        {
            // Освещение
            { BuiltInCategory.OST_LightingFixtures,       LoadCategory.Lighting },
            { BuiltInCategory.OST_LightingDevices,        LoadCategory.Lighting },
            // Силовые розетки / электроустройства
            { BuiltInCategory.OST_ElectricalFixtures,     LoadCategory.Sockets  },
            // Оборудование ЭОМ (щиты и т.п.) — общая сила
            { BuiltInCategory.OST_ElectricalEquipment,    LoadCategory.ForceGeneral },
            // Механическое оборудование (насосы, вентиляторы от ОВК)
            { BuiltInCategory.OST_MechanicalEquipment,    LoadCategory.ForcePumps },
            // Вертикальный транспорт
            { BuiltInCategory.OST_SpecialityEquipment,    LoadCategory.ForceLifts },
            // Пожарная сигнализация и противопожарное оборудование
            { BuiltInCategory.OST_FireAlarmDevices,       LoadCategory.Emergency },
            { BuiltInCategory.OST_SecurityDevices,        LoadCategory.Emergency },
        };

        // Маппинг текстового значения параметра → LoadCategory
        private static readonly Dictionary<string, LoadCategory> TextMap
            = new Dictionary<string, LoadCategory>(StringComparer.OrdinalIgnoreCase)
        {
            { "освещение",           LoadCategory.Lighting    },
            { "lighting",            LoadCategory.Lighting    },
            { "розетки",             LoadCategory.Sockets     },
            { "sockets",             LoadCategory.Sockets     },
            { "лифт",                LoadCategory.ForceLifts  },
            { "лифты",               LoadCategory.ForceLifts  },
            { "lift",                LoadCategory.ForceLifts  },
            { "насос",               LoadCategory.ForcePumps  },
            { "насосы",              LoadCategory.ForcePumps  },
            { "вентилятор",          LoadCategory.ForcePumps  },
            { "вентиляция",          LoadCategory.ForcePumps  },
            { "технологическое",     LoadCategory.ForceTech   },
            { "tech",                LoadCategory.ForceTech   },
            { "силовое",             LoadCategory.ForceGeneral},
            { "force",               LoadCategory.ForceGeneral},
            { "противопожарное",     LoadCategory.Emergency   },
            { "emergency",           LoadCategory.Emergency   },
        };

        public RevitEomProvider(Document doc, EomSettings settings)
        {
            _doc = doc ?? throw new ArgumentNullException(nameof(doc));
            _s   = settings ?? throw new ArgumentNullException(nameof(settings));
        }

        /// <summary>
        /// Собрать все нагрузочные элементы из модели.
        /// </summary>
        public List<EomLoadItem> GetAllItems()
        {
            var result = new List<EomLoadItem>();

            // Список категорий для сбора
            var categories = new[]
            {
                BuiltInCategory.OST_LightingFixtures,
                BuiltInCategory.OST_LightingDevices,
                BuiltInCategory.OST_ElectricalFixtures,
                BuiltInCategory.OST_ElectricalEquipment,
                BuiltInCategory.OST_MechanicalEquipment,
                BuiltInCategory.OST_SpecialityEquipment,
                BuiltInCategory.OST_FireAlarmDevices,
                BuiltInCategory.OST_SecurityDevices,
            };

            foreach (var cat in categories)
            {
                var elements = new FilteredElementCollector(_doc)
                    .OfCategory(cat)
                    .WhereElementIsNotElementType()
                    .ToElements();

                foreach (var el in elements)
                {
                    try
                    {
                        var item = BuildItem(el, cat);
                        if (item != null && item.PowerW > 0)
                            result.Add(item);
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine(
                            $"EomProvider skip {el.Id}: {ex.Message}");
                    }
                }
            }
            return result;
        }

        private EomLoadItem BuildItem(Element el, BuiltInCategory ost)
        {
            double powerW = GetPower(el);
            if (powerW <= 0) return null;

            // Определяем категорию нагрузки
            string catSource;
            LoadCategory loadCat = ResolveCategory(el, ost, out catSource);

            // Помещение
            string roomNum  = "";
            string roomName = "";
            TryGetRoom(el, out roomNum, out roomName);

            // Уровень
            string level = "";
            var lvlParam = el.get_Parameter(BuiltInParameter.FAMILY_LEVEL_PARAM)
                        ?? el.get_Parameter(BuiltInParameter.SCHEDULE_LEVEL_PARAM);
            if (lvlParam != null)
            {
                var lvlEl = _doc.GetElement(lvlParam.AsElementId());
                if (lvlEl != null) level = lvlEl.Name;
            }

            // Тип
            var famType = _doc.GetElement(el.GetTypeId());

            return new EomLoadItem
            {
                RevitId        = el.Id.IntegerValue,
                FamilyName     = el.get_Parameter(BuiltInParameter.ELEM_FAMILY_PARAM)
                                   ?.AsString() ?? el.Name,
                TypeName       = famType?.Name ?? "",
                RoomNumber     = roomNum,
                RoomName       = roomName,
                Level          = level,
                Category       = loadCat,
                PowerW         = powerW,
                CosPhi         = GetCosPhi(el),
                CategorySource = catSource,
            };
        }

        // ── Мощность ─────────────────────────────────────────────────
        private double GetPower(Element el)
        {
            // 1. Пробуем ADSK_Мощность (по имени)
            var p = el.LookupParameter(_s.PowerParamName);
            if (p != null && p.StorageType == StorageType.Double && p.AsDouble() > 0)
                return p.AsDouble();   // Revit хранит электрическую мощность в VA (ВА) как double

            // 2. Встроенный параметр Apparent Load / Electrical Connectors
            p = el.get_Parameter(BuiltInParameter.RBS_ELEC_APPARENT_LOAD);
            if (p != null && p.AsDouble() > 0)
                return p.AsDouble();   // VA

            // 3. Для светильников — Lamp Luminous Flux → нет; пробуем APPARENT_LOAD у типа
            var type = _doc.GetElement(el.GetTypeId());
            if (type != null)
            {
                p = type.LookupParameter(_s.PowerParamName);
                if (p != null && p.StorageType == StorageType.Double && p.AsDouble() > 0)
                    return p.AsDouble();

                p = type.get_Parameter(BuiltInParameter.RBS_ELEC_APPARENT_LOAD);
                if (p != null && p.AsDouble() > 0)
                    return p.AsDouble();
            }
            return 0;
        }

        // ── cosφ ──────────────────────────────────────────────────────
        private static double GetCosPhi(Element el)
        {
            var p = el.LookupParameter("cosφ")
                 ?? el.LookupParameter("cos_phi")
                 ?? el.LookupParameter("Коэффициент мощности")
                 ?? el.get_Parameter(BuiltInParameter.RBS_ELEC_POWER_FACTOR);
            if (p != null && p.StorageType == StorageType.Double)
            {
                double v = p.AsDouble();
                if (v > 0 && v <= 1) return v;
            }
            return 0; // 0 = использовать fallback из настроек
        }

        // ── Категория нагрузки ────────────────────────────────────────
        private LoadCategory ResolveCategory(Element el, BuiltInCategory ost,
            out string source)
        {
            // Приоритет 1: параметр семейства/экземпляра
            var p = el.LookupParameter(_s.CategoryParamName);
            if (p == null)
            {
                var type = _doc.GetElement(el.GetTypeId());
                if (type != null)
                    p = type.LookupParameter(_s.CategoryParamName);
            }
            if (p != null && p.StorageType == StorageType.String)
            {
                string val = (p.AsString() ?? "").Trim();
                if (TextMap.TryGetValue(val, out var fromParam))
                {
                    source = "Param";
                    return fromParam;
                }
            }

            // Приоритет 2: OST-категория
            if (OstMap.TryGetValue(ost, out var fromOst))
            {
                source = "OST";
                return fromOst;
            }

            source = "Unknown";
            return LoadCategory.Unknown;
        }

        // ── Помещение ─────────────────────────────────────────────────
        private void TryGetRoom(Element el, out string number, out string name)
        {
            number = "";
            name   = "";
            try
            {
                var locPt = (el.Location as LocationPoint)?.Point;
                if (locPt == null) return;

                var rooms = new FilteredElementCollector(_doc)
                    .OfCategory(BuiltInCategory.OST_Rooms)
                    .WhereElementIsNotElementType()
                    .Cast<Room>()
                    .Where(r => r.Area > 0);

                foreach (var room in rooms)
                {
                    if (room.IsPointInRoom(locPt))
                    {
                        number = room.get_Parameter(
                            BuiltInParameter.ROOM_NUMBER)?.AsString() ?? "";
                        name   = room.Name ?? "";
                        return;
                    }
                }
            }
            catch { }
        }
    }
}
