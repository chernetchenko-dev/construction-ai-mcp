using System;
using System.IO;
using System.Reflection;
using Autodesk.Revit.UI;
using HvacCalc.Core.Models;
using Newtonsoft.Json;

namespace HvacCalc.Addin
{
    public class App : IExternalApplication
    {
        internal static HvacSettings Settings       { get; private set; }
        internal static EomSettings  EomSettings    { get; private set; }
        internal static string       AssemblyDir    { get; private set; }
        internal static string       SettingsPath   { get; private set; }
        internal static string       EomSettingsPath{ get; private set; }

        public Result OnStartup(UIControlledApplication app)
        {
            AssemblyDir     = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            SettingsPath    = Path.Combine(AssemblyDir, "hvaccalc_settings.json");
            EomSettingsPath = Path.Combine(AssemblyDir, "hvaccalc_eom_settings.json");
            Settings        = LoadSettings();
            EomSettings     = LoadEomSettings();

            try { BuildRibbon(app); return Result.Succeeded; }
            catch (Exception ex)
            {
                TaskDialog.Show("HvacCalc", $"Ошибка загрузки:\n{ex.Message}");
                return Result.Failed;
            }
        }

        public Result OnShutdown(UIControlledApplication app)
        {
            SaveSettings(Settings);
            SaveEomSettings(EomSettings);
            return Result.Succeeded;
        }

        private void BuildRibbon(UIControlledApplication app)
        {
            const string tabName = "ОВиК + ЭОМ";
            string dll = Assembly.GetExecutingAssembly().Location;
            app.CreateRibbonTab(tabName);

            // ── ОВиК ─────────────────────────────────────────────────
            var ovk = app.CreateRibbonPanel(tabName, "Тепловой расчёт ОВиК");
            ovk.AddItem(Btn("CmdHeatLoss",    "Теплопотери",        dll, "HvacCalc.Addin.Commands.CmdHeatLoss",    "Расчёт Q по СП 60"));
            ovk.AddSeparator();
            ovk.AddItem(Btn("CmdEquipment",   "Оборудование",       dll, "HvacCalc.Addin.Commands.CmdEquipment",   "Подбор по Q"));
            ovk.AddItem(Btn("CmdWriteParams", "Записать\nв модель", dll, "HvacCalc.Addin.Commands.CmdWriteParams", "Записать Q в параметры"));
            ovk.AddSeparator();
            ovk.AddItem(Btn("CmdReport",      "Расчётная\nзаписка", dll, "HvacCalc.Addin.Commands.CmdReport",      "HTML-отчёт ОВиК"));
            ovk.AddItem(Btn("CmdSettings",    "Настройки",          dll, "HvacCalc.Addin.Commands.CmdSettings",    "Настройки ОВиК"));

            // ── ЭОМ ──────────────────────────────────────────────────
            var eom = app.CreateRibbonPanel(tabName, "ЭОМ — Расчёт нагрузок");
            eom.AddItem(Btn("CmdTrn",         "ТРН → Excel",        dll, "HvacCalc.Addin.Commands.CmdTrn",         "ТРН по СП 256 → .xlsx"));
            eom.AddSeparator();
            eom.AddItem(Btn("CmdEomSettings", "Настройки\nЭОМ",     dll, "HvacCalc.Addin.Commands.CmdEomSettings", "Тип здания, Ксп, cosφ"));
        }

        private static PushButtonData Btn(string name, string text,
            string dll, string cls, string tip)
            => new PushButtonData(name, text, dll, cls) { ToolTip = tip };

        // ── ОВиК settings ────────────────────────────────────────────
        internal static HvacSettings LoadSettings()
        {
            if (File.Exists(SettingsPath))
                try { return JsonConvert.DeserializeObject<HvacSettings>(
                    File.ReadAllText(SettingsPath, System.Text.Encoding.UTF8))
                    ?? new HvacSettings(); } catch { }
            return new HvacSettings();
        }
        internal static void SaveSettings(HvacSettings s)
        {
            try { File.WriteAllText(SettingsPath,
                JsonConvert.SerializeObject(s, Formatting.Indented),
                System.Text.Encoding.UTF8); } catch { }
        }

        // ── ЭОМ settings ─────────────────────────────────────────────
        internal static EomSettings LoadEomSettings()
        {
            if (File.Exists(EomSettingsPath))
                try { return JsonConvert.DeserializeObject<EomSettings>(
                    File.ReadAllText(EomSettingsPath, System.Text.Encoding.UTF8))
                    ?? new EomSettings(); } catch { }
            return new EomSettings();
        }
        internal static void SaveEomSettings(EomSettings s)
        {
            try { File.WriteAllText(EomSettingsPath,
                JsonConvert.SerializeObject(s, Formatting.Indented),
                System.Text.Encoding.UTF8); } catch { }
        }
    }
}
