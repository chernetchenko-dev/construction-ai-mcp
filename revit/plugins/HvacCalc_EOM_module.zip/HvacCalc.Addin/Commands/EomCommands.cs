using System;
using System.Diagnostics;
using System.IO;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using HvacCalc.Core.Models;
using HvacCalc.Core.Services;
using HvacCalc.RevitBridge;

namespace HvacCalc.Addin.Commands
{
    // ══════════════════════════════════════════════════════════════════
    // КОМАНДА: Сформировать ТРН ЭОМ → Excel
    // ══════════════════════════════════════════════════════════════════
    [Transaction(TransactionMode.ReadOnly)]
    public class CmdTrn : IExternalCommand
    {
        public Result Execute(ExternalCommandData cd, ref string msg, ElementSet els)
        {
            var doc = cd.Application.ActiveUIDocument.Document;
            var s   = App.EomSettings;

            try
            {
                // 1. Читаем нагрузки из Revit
                var provider = new RevitEomProvider(doc, s);
                var items    = provider.GetAllItems();

                if (items.Count == 0)
                {
                    TaskDialog.Show("ТРН ЭОМ",
                        "Не найдено ни одного элемента с ненулевой мощностью.\n\n" +
                        "Проверьте:\n" +
                        "• Заполнен ли параметр ADSK_Мощность в семействах\n" +
                        "• Или параметр RBS_ELEC_APPARENT_LOAD (Apparent Load)");
                    return Result.Cancelled;
                }

                // 2. Рассчитываем ТРН
                var calc   = new TrnCalculator(s);
                var result = calc.Calculate(
                    items,
                    App.EomSettings.ProjectName,
                    App.EomSettings.ProjectCode,
                    App.EomSettings.Engineer);

                // 3. Экспорт в Excel
                string outDir = string.IsNullOrEmpty(s.ReportOutputPath)
                    ? Path.GetDirectoryName(doc.PathName)
                    : s.ReportOutputPath;

                if (string.IsNullOrEmpty(outDir))
                    outDir = Environment.GetFolderPath(
                        Environment.SpecialFolder.Desktop);

                var exporter  = new TrnExcelExporter();
                string xlPath = exporter.Export(result, outDir);

                // 4. Показать результат
                var dlg = new TaskDialog("ТРН ЭОМ — готово");
                dlg.MainInstruction = $"ТРН сформирована: {items.Count} элементов";
                dlg.MainContent =
                    $"Установленная мощность: {result.PtotalInstalled:F1} кВт\n" +
                    $"Расчётная на вводе:      {result.PtotalCalc:F1} кВт  " +
                    $"({result.QtotalCalc:F1} квар)\n" +
                    $"Расчётный ток:           {result.ItotalCalc:F0} А\n\n" +
                    $"Файл: {xlPath}";
                dlg.AddCommandLink(TaskDialogCommandLinkId.CommandLink1,
                    "Открыть Excel");
                if (dlg.Show() == TaskDialogResult.CommandLink1)
                    Process.Start(xlPath);

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                return Result.Failed;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // КОМАНДА: Настройки ЭОМ
    // ══════════════════════════════════════════════════════════════════
    [Transaction(TransactionMode.ReadOnly)]
    public class CmdEomSettings : IExternalCommand
    {
        public Result Execute(ExternalCommandData cd, ref string msg, ElementSet els)
        {
            var dlg = new UI.EomSettingsWindow(App.EomSettings);
            if (dlg.ShowDialog() == true)
            {
                App.EomSettings = dlg.Result;
                App.SaveEomSettings(App.EomSettings);
            }
            return Result.Succeeded;
        }
    }
}
