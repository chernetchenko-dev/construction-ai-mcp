using System.Windows;
using System.Windows.Controls;
using HvacCalc.Core.Models;

namespace HvacCalc.Addin.UI
{
    /// <summary>
    /// Диалог настроек ЭОМ — тип здания, параметры, уровни Ксп.
    /// </summary>
    public class EomSettingsWindow : Window
    {
        public EomSettings Result { get; private set; }
        private readonly EomSettings _orig;

        private ComboBox  _cbBuildingType, _cbSocketLevel;
        private TextBox   _tbCatParam, _tbPowerParam;
        private TextBox   _tbCosLight, _tbCosSock, _tbCosLift, _tbCosPump;
        private TextBox   _tbKovr, _tbUkv;
        private TextBox   _tbProjectName, _tbProjectCode, _tbEngineer, _tbOutputPath;
        private CheckBox  _chkExclEmerg;

        public EomSettingsWindow(EomSettings current)
        {
            _orig  = current;
            Result = current;
            BuildUI();
            Load(current);
            Title  = "Настройки ЭОМ — ТРН";
            Width  = 500;
            Height = 640;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void BuildUI()
        {
            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
            var root   = new StackPanel { Margin = new Thickness(16) };
            scroll.Content = root;
            Content = scroll;

            // Проект
            AddHeader(root, "Реквизиты проекта");
            _tbProjectName = AddRow(root, "Наименование объекта:");
            _tbProjectCode = AddRow(root, "Шифр:");
            _tbEngineer    = AddRow(root, "Инженер-электрик:");
            _tbOutputPath  = AddRow(root, "Папка для Excel (пусто = рядом с .rvt):");

            // Здание
            AddHeader(root, "Тип здания (для Ксп освещения, табл. 7.6)");
            _cbBuildingType = AddCombo(root, "Тип здания:", new[]
            {
                "Административное / офисное",
                "Гостиница / санаторий",
                "Общественное питание / детский сад",
                "Школа / учебное заведение",
                "Торговля",
                "Актовый / конференц-зал (Ксп = 1)",
                "Клуб / дом культуры",
                "Кинотеатр",
            });

            // Параметры
            AddHeader(root, "Параметры Revit");
            _tbPowerParam = AddRow(root, "Параметр мощности:");
            _tbCatParam   = AddRow(root, "Параметр категории нагрузки:");

            // Розетки
            AddHeader(root, "Розетки (табл. 7.7)");
            _cbSocketLevel = AddCombo(root, "Уровень учёта розеток:", new[]
            {
                "Групповые сети (Ксп = 1.0)",
                "Питающие сети (Ксп = 0.2 / 0.4)",
                "Ввод здания (Ксп = 0.1 / 0.2)",
            });

            // cosφ
            AddHeader(root, "cosφ по умолчанию (табл. 7.12)");
            _tbCosLight = AddRow(root, "Освещение (ЛЛ, СД):");
            _tbCosSock  = AddRow(root, "Розетки:");
            _tbCosLift  = AddRow(root, "Лифты:");
            _tbCosPump  = AddRow(root, "Насосы / вентиляторы:");

            // Прочее
            AddHeader(root, "Прочее");
            _tbKovr = AddRow(root, "K несовпадения (0 = авто по табл. 7.11):");
            _tbUkv  = AddRow(root, "Напряжение, кВ:");
            _chkExclEmerg = AddCheck(root,
                "Исключить противопожарные из расчётной нагрузки");

            // Кнопки
            var btns = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 16, 0, 0)
            };
            var ok  = new Button { Content = "OK",     Width = 80,
                Margin = new Thickness(0, 0, 8, 0), IsDefault = true };
            var can = new Button { Content = "Отмена", Width = 80, IsCancel = true };
            ok.Click  += (_, __) => { Save(); DialogResult = true; };
            can.Click += (_, __) => { DialogResult = false; };
            btns.Children.Add(ok);
            btns.Children.Add(can);
            root.Children.Add(btns);
        }

        private void Load(EomSettings s)
        {
            _tbProjectName.Text   = s.ProjectName;
            _tbProjectCode.Text   = s.ProjectCode;
            _tbEngineer.Text      = s.Engineer;
            _tbOutputPath.Text    = s.ReportOutputPath;
            _cbBuildingType.SelectedIndex = (int)s.BuildingType;
            _tbPowerParam.Text    = s.PowerParamName;
            _tbCatParam.Text      = s.CategoryParamName;
            _cbSocketLevel.SelectedIndex  = s.SocketKspLevel;
            _tbCosLight.Text      = s.CosPhiLighting.ToString("F2");
            _tbCosSock.Text       = s.CosPhiSockets.ToString("F2");
            _tbCosLift.Text       = s.CosPhiLifts.ToString("F2");
            _tbCosPump.Text       = s.CosPhiPumps.ToString("F2");
            _tbKovr.Text          = s.KcoincidenceOverride.ToString("F2");
            _tbUkv.Text           = s.VoltageKv.ToString("F2");
            _chkExclEmerg.IsChecked = s.ExcludeEmergency;
        }

        private void Save()
        {
            Result = new EomSettings
            {
                ProjectName           = _tbProjectName.Text,
                ProjectCode           = _tbProjectCode.Text,
                Engineer              = _tbEngineer.Text,
                ReportOutputPath      = _tbOutputPath.Text,
                BuildingType          = (BuildingType)_cbBuildingType.SelectedIndex,
                PowerParamName        = _tbPowerParam.Text,
                CategoryParamName     = _tbCatParam.Text,
                SocketKspLevel        = _cbSocketLevel.SelectedIndex,
                CosPhiLighting        = D(_tbCosLight.Text,  _orig.CosPhiLighting),
                CosPhiSockets         = D(_tbCosSock.Text,   _orig.CosPhiSockets),
                CosPhiLifts           = D(_tbCosLift.Text,   _orig.CosPhiLifts),
                CosPhiPumps           = D(_tbCosPump.Text,   _orig.CosPhiPumps),
                CosPhiTech            = _orig.CosPhiTech,
                CosPhiForce           = _orig.CosPhiForce,
                KcoincidenceOverride  = D(_tbKovr.Text,      _orig.KcoincidenceOverride),
                VoltageKv             = D(_tbUkv.Text,       _orig.VoltageKv),
                ExcludeEmergency      = _chkExclEmerg.IsChecked == true,
            };
        }

        // ── helpers ──────────────────────────────────────────────────
        private static void AddHeader(Panel p, string t)
        {
            p.Children.Add(new TextBlock
            {
                Text = t, FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 12, 0, 4)
            });
        }

        private static TextBox AddRow(Panel p, string label)
        {
            var sp  = new StackPanel { Margin = new Thickness(0, 2, 0, 2) };
            var lbl = new TextBlock { Text = label, Margin = new Thickness(0, 0, 0, 1) };
            var tb  = new TextBox   { Height = 24, Padding = new Thickness(4, 2, 4, 2) };
            sp.Children.Add(lbl);
            sp.Children.Add(tb);
            p.Children.Add(sp);
            return tb;
        }

        private static ComboBox AddCombo(Panel p, string label, string[] items)
        {
            var sp  = new StackPanel { Margin = new Thickness(0, 2, 0, 2) };
            var lbl = new TextBlock { Text = label, Margin = new Thickness(0, 0, 0, 1) };
            var cb  = new ComboBox  { Height = 26 };
            foreach (var i in items) cb.Items.Add(i);
            cb.SelectedIndex = 0;
            sp.Children.Add(lbl);
            sp.Children.Add(cb);
            p.Children.Add(sp);
            return cb;
        }

        private static CheckBox AddCheck(Panel p, string label)
        {
            var cb = new CheckBox { Content = label, Margin = new Thickness(0, 4, 0, 4) };
            p.Children.Add(cb);
            return cb;
        }

        private static double D(string s, double fallback)
        {
            if (double.TryParse(s.Replace(',', '.'),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out double v))
                return v;
            return fallback;
        }
    }
}
